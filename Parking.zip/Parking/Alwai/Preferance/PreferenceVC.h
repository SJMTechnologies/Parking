//
//  PreferenceVC.h
//  Parking_ios
//
//  Created by Dips here... on 6/14/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"
#import "AppDelegate.h"
#import "IQKeyboardManager.h"
#import "MBProgressHUD.h"
#import "MyValidation.h"

@interface PreferenceVC : UIViewController{

    IBOutlet UIButton *btnBack;
    
    
    // Auth. Options
    
    IBOutlet UIView *viewAuthOpt_Main, *viewAuthOpt_inner;
    IBOutlet UIButton *btnAuthOpt_Pin,*btnAuthOpt_Psw,*btnAuthOpt_NoAuth;


}
@property(nonatomic,retain)IBOutlet UIButton *btnBack;


// Auth. Options
@property(nonatomic,retain)IBOutlet UIView *viewAuthOpt_Main;
@property(nonatomic,retain)IBOutlet UIView *viewAuthOpt_inner;
@property(nonatomic,retain)IBOutlet UIButton *btnAuthOpt_Pin;
@property(nonatomic,retain)IBOutlet UIButton *btnAuthOpt_Psw;
@property(nonatomic,retain)IBOutlet UIButton *btnAuthOpt_NoAuth;


@end
