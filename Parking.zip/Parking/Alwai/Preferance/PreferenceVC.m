//
//  PreferenceVC.m
//  Parking_ios
//
//  Created by Dips here... on 6/14/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import "PreferenceVC.h"
#import "SWRevealViewController.h"

@interface PreferenceVC ()

@end

@implementation PreferenceVC
@synthesize btnBack;


@synthesize viewAuthOpt_Main,viewAuthOpt_inner;
@synthesize btnAuthOpt_Pin, btnAuthOpt_Psw,btnAuthOpt_NoAuth;


- (void)viewDidLoad {
    NSLog(@"viewDidLoad...");
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController ){
        [btnBack addTarget:self.revealViewController action:@selector( revealToggle: ) forControlEvents:UIControlEventTouchUpInside];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
    [self getPreferenceDetails];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Get Preference Details

-(void)getPreferenceDetails{
    
    if ([APPDELEGATE check_InternetConnection]){
        NSDictionary *dictLogin = [APPDELEGATE login_getDetails];
        
        
        [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        NSString *post = [NSString stringWithFormat:@"%@%@",service_getPreference,[dictLogin valueForKey:@"auth_token"]];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:post]];
        [request setHTTPMethod:@"GET"];
        [request setTimeoutInterval:120];
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                    completionHandler:^
                                          (NSData *data, NSURLResponse *response, NSError *error) {
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                              });
                                              
                                              if (error) {
                                                  NSLog(@"error is: %@", error);
                                              } else {
                                                  NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                  NSLog(@"httpResponse:%@", httpResponse);
                                                  NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                  if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                      NSLog(@"preference dictRes --> %@", dictRes);
                                                      
                                                      if ([[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"code"] intValue] == 1){
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [USERDEFAULTS setValue:[[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"0"] valueForKey:@"radius"] forKey:@"distance"];
                                                              [USERDEFAULTS setValue:[[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"0"] valueForKey:@"auth_transaction"] forKey:@"AuthOption"];
                                                              [USERDEFAULTS setValue:[USERDEFAULTS valueForKey:@"AuthOption"] forKey:@"AuthOptionTEMP"];
                                                              
                                                          });
                                                      }else{
                                                          //                                                          [APPDELEGATE showMessage:@"" withTitle:@""];
                                                      }
                                                  }else{
                                                      //                                                      [APPDELEGATE showMessage:@"Username or password wrong." withTitle:@""];
                                                  }
                                              }
                                          }];
        [dataTask resume];
    }else{
        [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
    }
    
}


#pragma mark - Save Preference Details
-(void)SavePreferenceDetails:(NSString *)strDistance strAuthOption:(NSString *)strAuthOption{
    
    NSLog(@"Distance : %@",[USERDEFAULTS valueForKey:@"distance"]);
    NSLog(@"AuthOption : %@",[USERDEFAULTS valueForKey:@"AuthOption"]);
    
    
    if ([APPDELEGATE check_InternetConnection]){
        NSDictionary *dictLogin = [APPDELEGATE login_getDetails];
        
        // auth_token=&radius=&auth_transaction=
        [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        NSString *post = [NSString stringWithFormat:@"%@auth_token=%@&radius=%@&auth_transaction=%@",service_updatePreference,[dictLogin valueForKey:@"auth_token"],strDistance,strAuthOption];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:post]];
        [request setHTTPMethod:@"GET"];
        [request setTimeoutInterval:120];
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                    completionHandler:^
                                          (NSData *data, NSURLResponse *response, NSError *error) {
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                              });
                                              
                                              if (error) {
                                                  NSLog(@"error is: %@", error);
                                              } else {
                                                  NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                  NSLog(@"httpResponse:%@", httpResponse);
                                                  NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                  if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                      NSLog(@"update preference dictRes --> %@", dictRes);
                                                      
                                                      if ([[[[dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                          [APPDELEGATE showMessage:[[[dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"message"] withTitle:@""];
                                                          
                                                          [USERDEFAULTS setValue:strDistance forKey:@"distance"];
                                                          [USERDEFAULTS setValue:strAuthOption forKey:@"AuthOption"];
                                                          [USERDEFAULTS setValue:strAuthOption forKey:@"AuthOptionTEMP"];
                                                          
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [viewAuthOpt_Main setHidden:true];
                                                          });

                                                      }else{
                                                          [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                      }
                                                  }else{
                                                      [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                  }
                                              }
                                          }];
        [dataTask resume];
    }else{
        [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
    }
    
}



#pragma mark -
-(IBAction)action_Distance:(UIButton *)sender{
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"Distance"
                                                                              message: @""
                                                                       preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Distance";
        textField.textColor = [UIColor blueColor];
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.borderStyle = UITextBorderStyleRoundedRect;
        textField.keyboardType = UIKeyboardTypeDecimalPad;
        textField.text = [USERDEFAULTS valueForKey:@"distance"];
    }];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSArray * textfields = alertController.textFields;
        UITextField * namefield = textfields[0];
        NSLog(@"%@:",namefield.text);
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Done" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSArray * textfields = alertController.textFields;
        UITextField * namefield = textfields[0];
        NSLog(@"%@:",namefield.text);
        [self performSelector:@selector(getNewDistance:) withObject:namefield.text afterDelay:1.0];
    }]];
    
    [self presentViewController:alertController animated:YES completion:nil];

}

-(void)getNewDistance:(NSString *)strDistance{
    NSLog(@"strDistance:%@",strDistance);
    
    if([MyValidation checkAlphaNumericOnly:strDistance]){
//        [USERDEFAULTS setValue:strDistance forKey:@"distance"];
        [self SavePreferenceDetails:strDistance strAuthOption:[USERDEFAULTS valueForKey:@"AuthOption"]];
    }else{
        [APPDELEGATE showMessage:Alert_msg_AlphaNumericOnly withTitle:@""];
    }
}

#pragma mark -

-(IBAction)action_Authentication:(UIButton *)sender{
    [viewAuthOpt_Main setHidden:false];
    
    sender.tag = [[USERDEFAULTS valueForKey:@"AuthOption"] intValue];
    [self action_AuthOption_Options:sender];
}

-(IBAction)action_AuthOption_Options:(UIButton *)sender{

    [btnAuthOpt_Pin setImage:[UIImage imageNamed:@"radio_u.png"] forState:UIControlStateNormal];
    [btnAuthOpt_Psw setImage:[UIImage imageNamed:@"radio_u.png"] forState:UIControlStateNormal];
    [btnAuthOpt_NoAuth setImage:[UIImage imageNamed:@"radio_u.png"] forState:UIControlStateNormal];
    
    if (sender.tag == 0){
        [btnAuthOpt_Pin setImage:[UIImage imageNamed:@"radio_s.png"] forState:UIControlStateNormal];
    }else if (sender.tag == 1){
        [btnAuthOpt_Psw setImage:[UIImage imageNamed:@"radio_s.png"] forState:UIControlStateNormal];
    }else{
        [btnAuthOpt_NoAuth setImage:[UIImage imageNamed:@"radio_s.png"] forState:UIControlStateNormal];
    }
    
    [USERDEFAULTS setValue:[NSString stringWithFormat:@"%d",(int)sender.tag] forKey:@"AuthOptionTEMP"];
}

-(IBAction)action_AuthOption_Cancel:(UIButton *)sender{
    
    if(sender.tag == 0){
        [viewAuthOpt_Main setHidden:true];
    }else{
        if ([[USERDEFAULTS valueForKey:@"AuthOption"] intValue] != [[USERDEFAULTS valueForKey:@"AuthOptionTEMP"] intValue]){
            [self SavePreferenceDetails:[USERDEFAULTS valueForKey:@"Distance"] strAuthOption:[USERDEFAULTS valueForKey:@"AuthOptionTEMP"]];
        }else{
            [viewAuthOpt_Main setHidden:true];
        }
    }
    
}
@end
