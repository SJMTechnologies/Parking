//
//  ViewController.m
//  Copyright © 2017 sjm. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "MyValidation.h"
#import <Foundation/Foundation.h>
#import "HomeVC.h"

#import "ForgotPasswordVC.h"
#import <QuartzCore/QuartzCore.h>
#import "SWRevealViewController.h"
//import for test

#import "RegistrationVC.h"
#import "ChangePasswordVC.h"
//




@interface ViewController ()

@end

@implementation ViewController

@synthesize imgLogo,viewMain;
@synthesize btnLogin, btnSignUp, btnForgotPsw;
@synthesize txtEmail, txtPsw;
@synthesize btnShowHidePsw;



- (void)viewDidLoad {
    [super viewDidLoad];
   // [self.navigationController.navigationBar setHidden:true];
    
    appDelegate = APPDELEGATE;
    self.title = @"Parking";
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    [self setupView];
    
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:true];
    
    self.navigationController.navigationBar.hidden = true;

}


- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

-(void)setupView{


    self.navigationController.navigationBar.hidden = true;
    
    [self.view setBackgroundColor:color_lightBlue];
    [self.viewMain.layer setCornerRadius:5.0];
    
    [self.txtPsw setSecureTextEntry:true];
    
    [self.imgLogo.layer setCornerRadius:self.imgLogo.frame.size.width/2];
    [self.imgLogo.layer setBackgroundColor:[[UIColor whiteColor] CGColor]];
    [self.imgLogo.layer setShadowRadius:3.0];
    [self.imgLogo.layer setShadowColor:[[UIColor lightGrayColor] CGColor]];
    [self.imgLogo.layer setShadowOffset:CGSizeMake(0.0f, 1.0f)];
    [self.imgLogo.layer setShadowOpacity:0.5];
    [self.view bringSubviewToFront:self.imgLogo];
    [self.viewMain bringSubviewToFront:self.imgLogo];
    
    [self.btnForgotPsw setTitleColor:color_lightBlue forState:UIControlStateNormal];
    [self.btnSignUp setTitleColor:color_lightBlue forState:UIControlStateNormal];
    
    [self.btnLogin setBackgroundColor:color_lightBlue];
    [self.btnLogin setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.btnLogin.layer setCornerRadius:5.0];
    [self.btnLogin setTitle:@"Sign in" forState:UIControlStateNormal];
    
//    [self action_Login:btnLogin];
    
    GIDSignIn *signIn = [GIDSignIn sharedInstance];
    signIn.shouldFetchBasicProfile = YES;
    signIn.clientID = @"106173246804-sfhdiam4hqvs6uh9bprnjuqia7n3bm51.apps.googleusercontent.com";

    signIn.delegate = self;
    signIn.uiDelegate = self;

}


#pragma mark -


- (IBAction)action_Login:(UIButton *)sender {
    
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_swr"];
//    [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;
    
//    self.txtEmail.text = @"dipaksjm@gmail.com";
//    self.txtPsw.text = @"Reset123";
    
    
    
    if ([appDelegate check_InternetConnection]){
        if([appDelegate check_validateEmail:txtEmail.text]){
            if([MyValidation checkPasswordStandard:txtPsw.text]){
                [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
                NSString *post = [NSString stringWithFormat:@"%@email=%@&password=%@&device_token=%@",service_login,txtEmail.text,txtPsw.text,appDelegate.strDeviceToken];
                
                NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
                [request setURL:[NSURL URLWithString:post]];
                [request setHTTPMethod:@"GET"];
                [request setTimeoutInterval:240];
                
                NSURLSession *session = [NSURLSession sharedSession];
                NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                            completionHandler:^
                                                  (NSData *data, NSURLResponse *response, NSError *error) {
                                                      
                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                          [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                                      });
                                                      
                                                      if (error) {
                                                          NSLog(@"error is: %@", error);
                                                      } else {
                                                          NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                          NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                          if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                              
                                                              if ([[[[dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                                      [appDelegate login_saveChanges:[[dictRes valueForKey:@"result"] objectAtIndex:0]];
                                                                      UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                                                      SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_swr"];
                                                                      [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;
                                                                  });
                                                              }else{
                                                                  [appDelegate showMessage:@"Username or password wrong." withTitle:@""];
                                                              }
                                                          }else{
                                                              [appDelegate showMessage:@"Username or password wrong." withTitle:@""];
                                                          }
                                                      }
                                                  }];
                [dataTask resume];
            }else{
                [appDelegate showMessage:regi_PasswordValidate withTitle:@""];
            }
        }else{
            [appDelegate showMessage:Alert_msg_Validemail withTitle:@""];
        }
    }else{
        [appDelegate showMessage:Alert_msg_InternetError withTitle:@""];
    }
}

- (IBAction)action_SocialLogin:(UIButton *)sender {

    if (![appDelegate check_InternetConnection]){
        [appDelegate showMessage:Alert_msg_InternetError withTitle:@""];
        return;
    }

    
    if (sender.tag == 0){ // fb
        
        fbLoginMamanger = [[FBSDKLoginManager alloc] init];
        fbLoginMamanger.loginBehavior = FBSDKLoginBehaviorWeb;
        
        [fbLoginMamanger logInWithReadPermissions:[NSArray arrayWithObjects:@"email",@"user_birthday",@"public_profile", @"user_likes", nil] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
           
            if(error == nil){
                FBSDKLoginManagerLoginResult *fbloginresult = result;
                
                if(fbloginresult.grantedPermissions != nil){
                    if([fbloginresult.grantedPermissions containsObject:@"email"]){
                        [self getFBUserData];
                    }
                }
            }
        }];
    }else{ // g+
    
        [[GIDSignIn sharedInstance] signIn];
    }
}

-(void)getFBUserData{
    
    if([FBSDKAccessToken currentAccessToken] != nil){
        
//        FBSDKGraphRequest *objFBSDKGraphRequest = [[FBSDKGraphRequest alloc] ini];
        [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"id,email,name,first_name,last_name,gender,birthday"}]
         startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
             if (!error) {
//                 email=&password=&fname=&lname=&device_token=
                 
                 if ([result[@"email"] length] == 0){
                     [appDelegate showMessage:Alert_msg_Validemail withTitle:@""];
                     return ;
                 }
                 
                 if ([appDelegate check_InternetConnection]){
                     [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
                     NSString *post = [NSString stringWithFormat:@"%@email=%@&password=%@&fname=%@&lname=%@&device_token=%@",service_SocialLogin,result[@"email"],@"",result[@"first_name"],result[@"last_name"],appDelegate.strDeviceToken];
                     
                     NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
                     [request setURL:[NSURL URLWithString:post]];
                     [request setHTTPMethod:@"GET"];
                     [request setTimeoutInterval:240];
                     
                     NSURLSession *session = [NSURLSession sharedSession];
                     NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                                 completionHandler:^
                                                       (NSData *data, NSURLResponse *response, NSError *error) {
                                                           
                                                           dispatch_async(dispatch_get_main_queue(), ^{
                                                               [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                                           });
                                                           
                                                           if (error) {
                                                               NSLog(@"error is: %@", error);
                                                           } else {
                                                               NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                               NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                               if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                                   
                                                                   if ([[[[dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                                       dispatch_async(dispatch_get_main_queue(), ^{
                                                                           [appDelegate login_saveChanges:[[dictRes valueForKey:@"result"] objectAtIndex:0]];
                                                                           UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                                                           SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_swr"];
                                                                           [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;
                                                                       });
                                                                   }else{
                                                                       [appDelegate showMessage:@"Username or password wrong." withTitle:@""];
                                                                   }
                                                               }else{
                                                                   [appDelegate showMessage:@"Username or password wrong." withTitle:@""];
                                                               }
                                                           }
                                                       }];
                     [dataTask resume];
                 }else{
                     [appDelegate showMessage:Alert_msg_InternetError withTitle:@""];
                 }
             }
         }];
    }

}

- (IBAction)action_Signup:(UIButton *)sender{
    RegistrationVC *objRegistrationVC  = [[RegistrationVC alloc] initWithNibName:@"RegistrationVC" bundle:nil];
    [self.navigationController pushViewController:objRegistrationVC animated:YES];
}

- (IBAction)action_ForgotPSW:(UIButton *)sender{
//    ForgotPasswordVC *objForgotPasswordVC  = [[ForgotPasswordVC alloc] initWithNibName:@"ForgotPasswordVC" bundle:nil];
//    [self.navigationController pushViewController:objForgotPasswordVC animated:YES];
    
    UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"Forgot Password"
                                                                              message: @"Enter your email"
                                                                       preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"Email";
        textField.textColor = [UIColor blueColor];
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.borderStyle = UITextBorderStyleRoundedRect;
    }];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSArray * textfields = alertController.textFields;
        UITextField * namefield = textfields[0];
        NSLog(@"%@:",namefield.text);
        
    }]];
    [alertController addAction:[UIAlertAction actionWithTitle:@"Done" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSArray * textfields = alertController.textFields;
        UITextField * namefield = textfields[0];
        NSLog(@"%@:",namefield.text);
        
        [self performSelector:@selector(msg_forgotPsw_email:) withObject:namefield.text afterDelay:1.0];
        
    }]];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (IBAction)action_PasswordShowHide:(UIButton *)sender {
    [self.txtPsw setSecureTextEntry:true];
}

#pragma mark - GIDSignInDelegate

- (void)signIn:(GIDSignIn *)signIn
didSignInForUser:(GIDGoogleUser *)user
     withError:(NSError *)error {
    NSLog(@"didSignInForUser...");

    if (error) {
        NSLog(@"%@",[NSString stringWithFormat:@"Status: Authentication error: %@", error]);
        return;
    }else{
        NSString *userId = user.userID;                  // For client-side use only!
        NSString *idToken = user.authentication.idToken; // Safe to send to the server
        NSString *fullName = user.profile.name;
        NSString *givenName = user.profile.givenName;
        NSString *familyName = user.profile.familyName;
        NSString *email = user.profile.email;


        
        if ([appDelegate check_InternetConnection]){
            [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
            NSString *post = [NSString stringWithFormat:@"%@email=%@&password=%@&fname=%@&lname=%@&device_token=%@",service_SocialLogin,email,@"",fullName,fullName,appDelegate.strDeviceToken];
            
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
            [request setURL:[NSURL URLWithString:[post stringByReplacingOccurrencesOfString:@" " withString:@"%20"]]];
            [request setHTTPMethod:@"GET"];
            [request setTimeoutInterval:240];
            
            NSURLSession *session = [NSURLSession sharedSession];
            NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                        completionHandler:^
                                              (NSData *data, NSURLResponse *response, NSError *error) {
                                                  
                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                      [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                                  });
                                                  
                                                  if (error) {
                                                      NSLog(@"error is: %@", error);
                                                  } else {
                                                      NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                      NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                      if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                          
                                                          if ([[[[dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                                  [appDelegate login_saveChanges:[[dictRes valueForKey:@"result"] objectAtIndex:0]];
                                                                  UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                                                  SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_swr"];
                                                                  [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;
                                                              });
                                                          }else{
                                                              [appDelegate showMessage:@"Username or password wrong." withTitle:@""];
                                                          }
                                                      }else{
                                                          [appDelegate showMessage:@"Username or password wrong." withTitle:@""];
                                                      }
                                                  }
                                              }];
            [dataTask resume];
        }else{
            [appDelegate showMessage:Alert_msg_InternetError withTitle:@""];
        }
        
    }
}

- (void)signIn:(GIDSignIn *)signIn
didDisconnectWithUser:(GIDGoogleUser *)user
     withError:(NSError *)error {
    
    NSLog(@"didDisconnectWithUser...");
    if (error) {
        NSLog(@"%@",[NSString stringWithFormat:@"Status: Failed to disconnect: %@", error]);
    } else {
        NSLog(@"%@",[NSString stringWithFormat:@"Status: Disconnected"]);

    }
}

- (void)presentSignInViewController:(UIViewController *)viewController {
    [[self navigationController] pushViewController:viewController animated:YES];
}


#pragma mark -

-(void)msg_forgotPsw_email:(NSString *)strEmail{
    
    
    if([appDelegate check_validateEmail:strEmail]){
        
            if ([APPDELEGATE check_InternetConnection]){
                [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
                NSString *post = [NSString stringWithFormat:@"%@%@",service_forgotpassword,strEmail];
                
                NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
                [request setURL:[NSURL URLWithString:post]];
                [request setHTTPMethod:@"GET"];
                [request setTimeoutInterval:120];
                
                NSURLSession *session = [NSURLSession sharedSession];
                NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                            completionHandler:^
                                                  (NSData *data, NSURLResponse *response, NSError *error) {
                                                      
                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                          [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                                      });
                                                      
                                                      if (error) {
                                                          NSLog(@"error is: %@", error);
                                                      } else {
                                                          NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                          NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                          if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                              NSLog(@"forgot psw dictRes --> %@", dictRes);
                                                              if ([[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                                  
                                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                                      [APPDELEGATE showMessage:[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"message"] withTitle:@""];

                                                                  });
                                                                  
                                                              }else{
                                                                  [APPDELEGATE showMessage:[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"message"] withTitle:@""];
                                                              }
                                                          }else{
                                                              [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                          }
                                                      }
                                                  }];
                [dataTask resume];
            }else{
                [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
            }
        
    }else{
        [appDelegate showMessage:Alert_msg_Validemail withTitle:@"Oops!"];
    }
    
}



@end
