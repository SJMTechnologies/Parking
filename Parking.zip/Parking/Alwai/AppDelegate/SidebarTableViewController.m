

#import "SidebarTableViewController.h"
#import "SWRevealViewController.h"
#import "ChangePasswordVC.h"
#import "ProfileVC.h"
#import "PreferenceVC.h"

@interface SidebarTableViewController ()

@end


@implementation SidebarTableViewController {
    NSArray *menuItems;
}
@synthesize lblUser,lblEmail;


- (void)viewDidLoad {
    [super viewDidLoad];
    menuItems = @[@"Home", @"news", @"comments", @"map", @"calendar"];

//    menuItems = @[@"Home", @"news", @"comments", @"map", @"calendar", @"wishlist", @"bookmark", @"tag"];
    
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color_lightBlue;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return menuItems.count;
//    return 15;

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if(indexPath.row == 0){
        return 150;
    }
       return 44;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *CellIdentifier = [menuItems objectAtIndex:indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    [tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    if (indexPath.row == 0){
//        cell.textLabel.text = @"Park";
        cell.backgroundColor = color_lightBlue;
        cell.textLabel.textColor = [UIColor whiteColor];
    }else{
        
        cell.backgroundColor = [UIColor whiteColor];
        cell.contentView.backgroundColor = [UIColor whiteColor];
        cell.textLabel.textColor = [UIColor blackColor];

    }

    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    NSLog(@"indexPath.row:%ld",(long)indexPath.row);
    if (indexPath.row == 0){
        // user name
    }else  if (indexPath.row == 1) {
        ProfileVC *objProfileVC = [[ProfileVC alloc] initWithNibName:@"ProfileVC" bundle:nil];
        [self.revealViewController pushFrontViewController:objProfileVC animated:true];
        
    }else if (indexPath.row == 2) {
//        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//        SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_ViewController"];
//        [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;

//        ChangePasswordVC *objChangePasswordVC = [[ChangePasswordVC alloc] initWithNibName:@"ChangePasswordVC" bundle:nil];
//        [self.revealViewController pushFrontViewController:objChangePasswordVC animated:true];
        
        PreferenceVC *objPreferenceVC = [[PreferenceVC alloc] initWithNibName:@"PreferenceVC" bundle:nil];
        [self.revealViewController pushFrontViewController:objPreferenceVC animated:true];


    }else  if (indexPath.row == 3) { // logout
        [self showLogoutOption];
    }
}

-(void)showLogoutOption{
    
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Please Confirm"
                                                                       message:@"Are you sure want to Logout?"
                                                                preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *firstAction = [UIAlertAction actionWithTitle:@"YES"
                                                              style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                                  NSLog(@"You pressed button YES");
                                                                  
                                                                  [self action_Logout];
                                                                  
                                                              }];
        UIAlertAction *secondAction = [UIAlertAction actionWithTitle:@"NO"
                                                               style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                                   NSLog(@"You pressed button NO");
                                                               }];
        
        [alert addAction:firstAction];
        [alert addAction:secondAction];
    

    if(isiPhone){
        [self presentViewController:alert animated:YES completion:nil];
    }else{
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [alert setModalPresentationStyle:UIModalPresentationPopover];
            UIPopoverPresentationController *popPresenter = [alert popoverPresentationController];
            popPresenter.sourceView = self.tableView;
            popPresenter.sourceRect = self.tableView.bounds;
            [self presentViewController:alert animated:YES completion:nil];
        });
    }
    
    
}

- (void)action_Logout{
    
    NSDictionary *dictLogin = [APPDELEGATE login_getDetails];
    
    if ([APPDELEGATE check_InternetConnection]){
                [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
                NSString *post = [NSString stringWithFormat:@"%@%@",service_logout,[dictLogin valueForKey:@"auth_token"]];
                
                NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
                [request setURL:[NSURL URLWithString:post]];
                [request setHTTPMethod:@"GET"];
                [request setTimeoutInterval:120];
                
                NSURLSession *session = [NSURLSession sharedSession];
                NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                            completionHandler:^
                                                  (NSData *data, NSURLResponse *response, NSError *error) {
                                                      
                                                      dispatch_async(dispatch_get_main_queue(), ^{
                                                          [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                                      });
                                                      
                                                      if (error) {
                                                          NSLog(@"error is: %@", error);
                                                      } else {
                                                          NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                          NSLog(@"httpResponse:%@", httpResponse);
                                                          NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                          if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                              NSLog(@"login dictRes --> %@", dictRes);
                                                              if ([[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                                  
                                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                                      
                                                                      [USERDEFAULTS removeObjectForKey:@"loginDetails"];
                                                                      [USERDEFAULTS synchronize];
                                                                      
                                                                      UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                                                                      SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_ViewController"];
                                                                      UINavigationController *objNav = [[UINavigationController alloc]initWithRootViewController:mainmenuvc];
                                                                      
                                                                      [[[UIApplication sharedApplication]delegate] window].rootViewController = objNav;
                                                                  });

                                                              }else{
                                                                  [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                              }

                                                             
                                                          }else{
                                                              [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                          }
                                                          
                                                      }
                                                      
                                                  }];
                [dataTask resume];
            
        
    }else{
        [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
    }
    
    //    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    //    SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_swr"];
    //    [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;
}

@end
//
