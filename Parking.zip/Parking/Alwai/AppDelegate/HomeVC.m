//
//  HomeVC.m
//
//  Copyright © 2017 sjm. All rights reserved.
//

#import "HomeVC.h"
#import <QuartzCore/QuartzCore.h>
#import "SWRevealViewController.h"
#import "Constant.h"
#import "ParkNow.h"
#import "ParkLaterVC.h"


@interface HomeVC ()

@end

@implementation HomeVC
@synthesize btnParkNow, btnParkLater;



- (void)viewDidLoad {
    [super viewDidLoad];

    

    self.title = @"Park";

    self.navigationController.navigationBar.titleTextAttributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"System-Medium" size:FONT_NAVI_TITTLE_SIZE],NSFontAttributeName,                                                                   [UIColor whiteColor],NSForegroundColorAttributeName,nil];
    
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];

    self.navigationController.navigationBar.backgroundColor = color_lightBlue;
    self.navigationController.navigationBar.barTintColor = color_lightBlue;

    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController ){
        [self.sidebarButton setTarget: self.revealViewController];
        [self.sidebarButton setAction: @selector( revealToggle: )];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark -

- (IBAction)action_Park:(UIButton *)sender{

    if(sender.tag == 0){
        ParkNow *objParkNow = [[ParkNow alloc] initWithNibName:@"ParkNow" bundle:nil];
        [self.navigationController pushViewController:objParkNow animated:true];
    }else{
        ParkLaterVC *objParkLaterVC = [[ParkLaterVC alloc] initWithNibName:@"ParkLaterVC" bundle:nil];
        [self.navigationController pushViewController:objParkLaterVC animated:true];

    }
}





@end
