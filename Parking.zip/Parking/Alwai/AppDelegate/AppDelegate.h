//
//  AppDelegate.h
//
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
//#import <FBSDKCoreKit/FBSDKCoreKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>{

    NSMutableDictionary *dictLogin;

    
    
    NSMutableString *strNotificationID; // for both event id and notification id
    NSString *strNotificationType; // for both event id and notification id

    // no network message...
    NSString *strNoNetworkTittle;
    NSString *strNoNetworkMessage;
    CLLocationManager *locationManager;
    CLLocation *currentLocation;
    
    NSMutableString *strCurrentLat;
    NSMutableString *strCurrentLon;
    
    
    
    
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSString  *strDeviceToken;

@property (strong, nonatomic)NSString *strNoNetworkTittle;
@property (strong, nonatomic)NSString *strNoNetworkMessage;
@property (strong, nonatomic)CLLocationManager *locationManager;
@property (strong, nonatomic)CLLocation *currentLocation;

@property (strong, nonatomic)NSMutableString *strCurrentLat;
@property (strong, nonatomic)NSMutableString *strCurrentLon;


@property (strong, nonatomic) NSMutableDictionary *dictLogin;

-(BOOL)check_validateEmail:(NSString*) emailString;
- (NSString *)hexStringFromColor:(UIColor *)color ;
- (UIColor *)colorWithHexString: (NSString *)hexString;
- (UIImage*)loadImage:(NSString *)strImage;
-(void)showMessage:(NSString*)message withTitle:(NSString *)title;
-(void)login_saveChanges:(NSMutableDictionary *)dictNew;
-(NSMutableDictionary *)login_getDetails;
-(NSString *)checkNullorNot:(NSString *)strCheckNull;
- (BOOL)check_InternetConnection;
@end

