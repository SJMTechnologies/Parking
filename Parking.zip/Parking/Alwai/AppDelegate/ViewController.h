//
//  ViewController.h
//
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>

#import <GoogleSignIn/GoogleSignIn.h>
#import "AuthInspectorViewController.h"

@interface ViewController : UIViewController<UITextFieldDelegate,UIScrollViewDelegate,GIDSignInDelegate, GIDSignInUIDelegate>{

    IBOutlet UIImageView *imgLogo;
    IBOutlet UIView *viewMain;
    IBOutlet UITextField *txtEmail, *txtPsw;
    
    IBOutlet UIButton *btnLogin, *btnSignUp, *btnForgotPsw;
    AppDelegate *appDelegate;
    IBOutlet UIButton *btnShowHidePsw;
    
    //
    
    FBSDKLoginManager *fbLoginMamanger;
    
}
@property(nonatomic,retain)IBOutlet UIImageView *imgLogo;
@property(nonatomic,retain)IBOutlet UIView *viewMain;

@property(nonatomic,retain)IBOutlet UIButton *btnLogin;
@property(nonatomic,retain)IBOutlet UIButton *btnSignUp;
@property(nonatomic,retain)IBOutlet UIButton *btnForgotPsw;


@property(nonatomic,retain)IBOutlet UITextField *txtEmail;
@property(nonatomic,retain)IBOutlet UITextField *txtPsw;

@property(nonatomic,retain)IBOutlet UIButton *btnShowHidePsw;

@end

