

#import <UIKit/UIKit.h>
#import "SWRevealViewController.h"
#import "Constant.h"
#import "AppDelegate.h"

@interface SidebarTableViewController : UITableViewController<SWRevealViewControllerDelegate>{

    IBOutlet UILabel *lblUser, *lblEmail;
}
@property(nonatomic,retain)IBOutlet UILabel *lblUser;
@property(nonatomic,retain)IBOutlet UILabel *lblEmail;
@end
