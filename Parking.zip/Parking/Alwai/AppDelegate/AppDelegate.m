//
//  AppDelegate.m
//
//  Copyright © 2017 sjm. All rights reserved.
//

#import "AppDelegate.h"

#import "IQKeyboardManager.h"
#import "Constant.h"
#import "SWRevealViewController.h"
#import "Reachability.h"

#import <GoogleSignIn/GoogleSignIn.h>



@interface AppDelegate ()

@end

@implementation AppDelegate
@synthesize strDeviceToken;
@synthesize dictLogin;
@synthesize locationManager;
@synthesize currentLocation;

@synthesize strNoNetworkTittle, strNoNetworkMessage;
@synthesize strCurrentLat, strCurrentLon;
static NSString * const kClientID = @"106173246804-sfhdiam4hqvs6uh9bprnjuqia7n3bm51.apps.googleusercontent.com";


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    NSLog(@"didFinishLaunchingWithOptions...");
    
    
    
    strCurrentLat = [[NSMutableString alloc] init];
    strCurrentLon = [[NSMutableString alloc] init];
    
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone; //whenever we move
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;    
    [locationManager startUpdatingLocation];
    [locationManager requestWhenInUseAuthorization];

    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:YES];
    
    [[UINavigationBar appearance] setTintColor:color_lightBlue];

    
//    /*
    if ([application respondsToSelector:@selector(registerUserNotificationSettings:)])
    {
        UIUserNotificationType userNotificationTypes = (UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound);
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:userNotificationTypes categories:nil];
        [application registerUserNotificationSettings:settings];
        [application registerForRemoteNotifications];
    }
    else
    {
        // Register for Push Notifications, if running iOS version < 8
        [application registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound)];
    }
//    */
    
    
   /*
     application.applicationIconBadgeNumber = 0;
     if(SYSTEM_VERSION_LESS_THAN( @"10.0" ) ){
         [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound |    UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
         [[UIApplication sharedApplication] registerForRemoteNotifications];
     
     }else{
         UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
         center.delegate = self;
         [center requestAuthorizationWithOptions:(UNAuthorizationOptionSound | UNAuthorizationOptionAlert | UNAuthorizationOptionBadge) completionHandler:^(BOOL granted, NSError * _Nullable error){
             if( !error )
             {
                 [[UIApplication sharedApplication] registerForRemoteNotifications];  // required to get the app to do anything at all about push notifications
                 NSLog( @"Push registration success." );
             }else{
                 NSLog( @"Push registration FAILED" );
                 NSLog( @"ERROR: %@ - %@", error.localizedFailureReason, error.localizedDescription );
                 NSLog( @"SUGGESTIONS: %@ - %@", error.localizedRecoveryOptions, error.localizedRecoverySuggestion );
             }
         }];
    }
    */
    
    if([[[USERDEFAULTS dictionaryRepresentation] allKeys] containsObject:@"distance"]){ }
    else{
        [USERDEFAULTS setValue:@"1000" forKey:@"distance"];
    }
    
    if([[[USERDEFAULTS dictionaryRepresentation] allKeys] containsObject:@"AuthOption"]){ }
    else{
        [USERDEFAULTS setValue:@"0" forKey:@"AuthOption"];
    }
    
    
        strNoNetworkTittle = @"Oops!!!";
        strNoNetworkMessage = @"Network is not available.";
    
    
    
    
//    [[FBSDKApplicationDelegate sharedInstance] application:application
//                             didFinishLaunchingWithOptions:launchOptions];


    return YES;
}

//- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
//  sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
//    
//    BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
//                                                                  openURL:url
//                                                        sourceApplication:sourceApplication
//                                                               annotation:annotation
//                    ];
//    // Add any custom logic here.
//    return handled;
//} 


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    
    NSLog(@"applicationWillResignActive...");

}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    NSLog(@"applicationDidEnterBackground...");

}

- (void)applicationWillEnterForeground:(UIApplication *)application {

    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    NSLog(@"applicationWillEnterForeground...");

}

- (void)applicationDidBecomeActive:(UIApplication *)application {

    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    NSLog(@"applicationDidBecomeActive...");

}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    NSLog(@"applicationWillTerminate...");

}

#pragma mark -

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    return [[GIDSignIn sharedInstance] handleURL:url
                               sourceApplication:sourceApplication
                                      annotation:annotation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//    [errorAlert show];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
//    NSLog(@"didUpdateToLocation: %@", newLocation);
//    CLLocation *currentLocation = newLocation;
    
    if (newLocation != nil) {
        currentLocation = newLocation;
        [strCurrentLon setString:[NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude]];
        [strCurrentLat setString:[NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude]];
    }
}

#pragma mark -
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings{ // NS_AVAILABLE_IOS(8_0);
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken{
    
    strDeviceToken = [NSString stringWithFormat:@"%@", deviceToken];
    strDeviceToken = [strDeviceToken stringByReplacingOccurrencesOfString:@" " withString:@""];
    strDeviceToken = [strDeviceToken stringByReplacingOccurrencesOfString:@"<" withString:@""];
    strDeviceToken = [strDeviceToken stringByReplacingOccurrencesOfString:@">" withString:@""];
    
    NSLog(@"strDeviceToken: %@", strDeviceToken);
    
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    NSLog(@"userInfo:%@",userInfo);
    

    
    if ([[self login_getDetails] valueForKey:@"auth_token"])
    {
        NSLog(@"User  login...");
        dispatch_async(dispatch_get_main_queue(), ^{
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_swr"];
            [[[UIApplication sharedApplication]delegate] window].rootViewController = mainmenuvc;
        });
        
    }else{
        NSLog(@"User not login...");
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        SWRevealViewController *mainmenuvc = [storyboard instantiateViewControllerWithIdentifier:@"id_ViewController"];
        UINavigationController *objNav = [[UINavigationController alloc]initWithRootViewController:mainmenuvc];
        [[[UIApplication sharedApplication]delegate] window].rootViewController = objNav;
    }
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))completionHandler{
    
    
}



#pragma mark -
- (BOOL)check_InternetConnection{
    Reachability * reach = [Reachability reachabilityForInternetConnection];
    if ([reach isReachable]) {
        return YES;
    }
    return NO;
}

-(BOOL)check_validateEmail:(NSString*) emailString{
    NSString *regExPattern = @"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$";
    NSRegularExpression *regEx = [[NSRegularExpression alloc] initWithPattern:regExPattern options:NSRegularExpressionCaseInsensitive error:nil];
    NSUInteger regExMatches = [regEx numberOfMatchesInString:emailString options:0 range:NSMakeRange(0, [emailString length])];
    if (regExMatches == 0) {
        return NO;
    }else
        return YES;
}
- (NSString *)hexStringFromColor:(UIColor *)color {
    const CGFloat *components = CGColorGetComponents(color.CGColor);
    
    CGFloat r = components[0];
    CGFloat g = components[1];
    CGFloat b = components[2];
    
    return [NSString stringWithFormat:@"#%02lX%02lX%02lX",
            lroundf(r * 255),
            lroundf(g * 255),
            lroundf(b * 255)];
}

- (UIColor *) colorWithHexString: (NSString *) hexString{
    NSString *colorString = [[hexString stringByReplacingOccurrencesOfString: @"#" withString: @""] uppercaseString];
    
    NSLog(@"colorString :%@",colorString);
    CGFloat alpha, red, blue, green;
    
    // #RGB
    alpha = 1.0f;
    red   = [self colorComponentFrom: colorString start: 0 length: 2];
    green = [self colorComponentFrom: colorString start: 2 length: 2];
    blue  = [self colorComponentFrom: colorString start: 4 length: 2];
    
    return [UIColor colorWithRed: red green: green blue: blue alpha: alpha];
}
- (CGFloat) colorComponentFrom: (NSString *) string start: (NSUInteger) start length: (NSUInteger) length {
    NSString *substring = [string substringWithRange: NSMakeRange(start, length)];
    NSString *fullHex = length == 2 ? substring : [NSString stringWithFormat: @"%@%@", substring, substring];
    unsigned hexComponent;
    [[NSScanner scannerWithString: fullHex] scanHexInt: &hexComponent];
    return hexComponent / 255.0;
}

- (UIImage*)loadImage:(NSString *)strImage{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString* path = [documentsDirectory stringByAppendingPathComponent:
                      [NSString stringWithString: strImage]];
    UIImage* image = [UIImage imageWithContentsOfFile:path];
    return image;
}

-(void)showMessage:(NSString*)message withTitle:(NSString *)title{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            
        }]];
        
        [[[[UIApplication sharedApplication] keyWindow] rootViewController] presentViewController:alertController animated:YES completion:^{
        }];
    });
}
-(NSString *)checkNullorNot:(NSString *)strCheckNull{
    if ( ( ![strCheckNull isEqual:[NSNull null]] ) && ( [strCheckNull length] != 0 ) ) {
        
    }else{
        strCheckNull = @"";
    }
    
    
    return strCheckNull;
}

-(void)login_saveChanges:(NSMutableDictionary *)dictNew{
    NSLog(@"dictNew : %@",dictNew);

    [USERDEFAULTS setValue:dictNew forKey:@"loginDetails"];
    [USERDEFAULTS synchronize];
    
    NSLog(@"Login Details save here : %@",[USERDEFAULTS valueForKey:@"loginDetails"]);
}

-(NSMutableDictionary *)login_getDetails{
    NSMutableDictionary *ditLD = [[NSMutableDictionary alloc] initWithDictionary:[USERDEFAULTS valueForKey:@"loginDetails"]];
    NSLog(@"Login Details get here : %@",[USERDEFAULTS valueForKey:@"loginDetails"]);

    return ditLD;
}

#pragma mark -


@end
