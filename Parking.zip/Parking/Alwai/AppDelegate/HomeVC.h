//
//  HomeVC.h
//
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface HomeVC : UIViewController{

    

    IBOutlet UIButton *btnParkNow, *btnParkLater;

}
@property(nonatomic,retain)IBOutlet UIButton *btnParkNow;
@property(nonatomic,retain)IBOutlet UIButton *btnParkLater;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *sidebarButton;



@end
