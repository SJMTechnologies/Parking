//
//  Constant.h
//

#ifndef DemoForConstant_Constant_h
#define DemoForConstant_Constant_h

#define APPDELEGATE ((AppDelegate *)[[UIApplication sharedApplication] delegate])
#define USERDEFAULTS [NSUserDefaults standardUserDefaults]

// WEB SERVICE
#define service_login  @"http://54.162.93.65/services/web-services.php?web_method=login&"
#define service_SocialLogin @"http://54.162.93.65/services/web-services.php?web_method=social_user_signup&"
#define service_register  @"http://54.162.93.65/services/web-services.php?web_method=signup&"
#define service_logout  @"http://54.162.93.65/services/web-services.php?web_method=logout&auth_token="
#define service_forgotpassword  @"http://54.162.93.65/services/web-services.php?web_method=forgotPassword&email="


#define service_country  @"http://54.162.93.65/services/web-services.php?web_method=getCountry"
#define service_state  @"http://54.162.93.65/services/web-services.php?web_method=getState&country_id="


#define service_profile   @"http://54.162.93.65/services/web-services.php?web_method=getProfile&auth_token="
#define service_updateProfile  @"http://54.162.93.65/services/web-services.php?web_method=updateProfile&"

#define service_getPreference  @"http://54.162.93.65/services/web-services.php?web_method=getPreference&auth_token="
#define service_updatePreference  @"http://54.162.93.65/services/web-services.php?web_method=updatePreference&"

#define service_getMeter  @"http://54.162.93.65/services/web-services.php?web_method=getMeters&"

/*
 

 Found bellow error...
 
 {
 result: - {
 rows: - {
 0:[],
 code: "0",
 message: "No meter found.",
 sqlStr: "SELECT Area, Post, lat, `long`, SQRT( POW( 69.1 * ( lat - 40.7128 ) , 2 ) + POW( 69.1 * ( 74.0059 - `long` ) * COS( lat / 57.3 ) , 2 ) ) AS distance2, CASE WHEN tblPosts.ExpiresAt > NOW() THEN CONCAT ('EXPIRES IN: ', SEC_TO_TIME((ROUND(TIME_TO_SEC(TIMEDIFF(tblPosts.ExpiresAt, NOW())))))) ELSE 'Expired' END AS 'status' FROM tblPosts HAVING distance2 < 0.018939393939394 ORDER BY `distance2` limit 0, 5"
 }
 }
 }
*/


/*
 

 

 12. http://54.162.93.65/services/web-services.php?web_method=getMeters&auth_token=&latitude=&longitude=
 13. http://54.162.93.65/services/web-services.php?web_method=checkAvailability&auth_token=&selected_date=&selected_time=&post=
 
 
 
*/

// DEVICE TYPE
#define isiPhone  (UI_USER_INTERFACE_IDIOM() == 0)?TRUE:FALSE
#define isiPhone5  ([[UIScreen mainScreen] bounds].size.height == 568)?TRUE:FALSE


// ALERT
#define ALERT(msg) {UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"" message:msg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];[alert show];}

#define ALERT_WITH_TITLE(msg,title) {UIAlertView* alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];[alert show];}

// paypal
#define kPayPalEnvironment PayPalEnvironmentNoNetwork  // check this if live or sandbox

// VERSION
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)

// COUNTRY
#define  COUNTRY_NAME @"name"
#define  COUNTRY_CODE @"countryCode"
#define  CURRENCY_CODE @"currencyCode"
#define  CURRENCY_SYMBOL @"currencytSymbol"

// FONT
#define FONT_ADOBE_MEDIUM @""
#define FONT_NAVI_TITTLE_SIZE 24.0

// SIDEBAR
#define x_menubtn ([UIScreen mainScreen].bounds.size.width)/1.5
#define bar_tableviewwidth ([UIScreen mainScreen].bounds.size.width)/1.0
#define barmain_tableviewwidth 320
#define side_menuColor [UIColor darkGrayColor]
#define frameheight [UIScreen mainScreen].bounds.size.height
#define navigationbar_height 170 
#define y_height_for_bottom [UIScreen mainScreen].bounds.size.height-130
#define navigationbar_button_height 30
#define tableview_height  ((UI_USER_INTERFACE_IDIOM()== UIUserInterfaceIdiomPad)?100:60)
#define sidemanu_topdist 20
#define width_sidebar_dist 60

// color
#define color_lightBlue [UIColor colorWithRed:95.0/255.0 green:176.0/255.0 blue:201.0/255.0 alpha:1.0]

// Alert Message
#define Alert_msg_InternetError           @"The Internet connection appears to be offline."
#define Alert_msg_Validemail              @"Please enter valid email."
#define Alert_msg_AllRequired             @"Please fill all field."
#define Alert_msg_PhoneRequired           @"Please enter phone number."
#define Alert_msg_PhoneDigitRequired      @"Please enter valid 10 digit phone number."
#define Alert_msg_AlphaNumericOnly        @"Please enter the alpha numberic value only"

#define Alert_msg_loginRequired           @"Login Required."
#define Alert_msg_loginsuccessfully       @"User login successfully."
#define Alert_msg_PasswordMismatch        @"Password does not match with confirm password."
#define Alert_msg_Logout                  @"Are you sure you want to logout?"
#define Alert_msg_PasswordLengthShort     @"Please enter the Password"

#define Alert_msg_ProfileSave             @"Profile Save Sucessfully."
#define Alert_msg_Tryagain                @"Please try again."
#define Alert_msg_NoData                  @"No records found."
#define Alert_msg_Select                  @"Please select"




// Registration form msg
#define regi_FirstName                    @"Please enter the First Name"
#define regi_LastName                     @"Please enter the Last Name"
#define regi_EmailEnter                   @"Please enter the Email"
#define regi_EmailValidate                @"Please enter the valid Email"
#define regi_TelephoneEnter               @"Please enter the Telephone"
#define regi_TelephoneValid               @"Please enter the valid Telephone number"

#define regi_Address1                     @"Please enter the Address 1"
#define regi_City                         @"Please enter the City"
#define regi_PostalCodeEnter              @"Please enter the Postal Code"
#define regi_PostalCodeValid              @"Please enter the Valid Postal Code"

#define regi_PasswordEnter                @"Please enter the Password"
#define regi_PasswordValidate             @"Password should be contain one lowercase letter, one uppercase letter and one number."
#define regi_ConfirmPasswordEnter         @"Please enter the Confirm Password"
#define regi_ConfirmPasswordValidate      @"Confirm Password should be contain one lowercase letter, one uppercase letter and one number."
#define regi_PassConfiPassNotSame         @"Password and Confirm Password not same"

#define regi_PrivacyPolicy                @"Please confirm, you are agree with Privacy Policy"



#endif

