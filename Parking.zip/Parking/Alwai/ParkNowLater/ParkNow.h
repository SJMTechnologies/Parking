//
//  ParkNow.h
//  Parking_ios
//
//  Created by Dips here... on 6/9/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Constant.h"
#import "AppDelegate.h"
#import "MeterVC.h"

@interface ParkNow : UIViewController<MKMapViewDelegate>{

    IBOutlet MKMapView *mapViewMain;
    AppDelegate *appDelegate;
    
    NSString *strFullAddr;
}

@property(nonatomic,retain)IBOutlet MKMapView *mapViewMain;
@end
