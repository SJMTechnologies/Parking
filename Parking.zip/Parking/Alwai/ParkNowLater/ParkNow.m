//
//  ParkNow.m
//  Parking_ios
//
//  Created by Dips here... on 6/9/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import "ParkNow.h"
#import "MyLocation.h"
#define METERS_PER_MILE 1609.344


@interface ParkNow ()

@end

@implementation ParkNow
@synthesize mapViewMain;

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Park Now";
    
    appDelegate = APPDELEGATE;
    
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    strFullAddr = [[NSString alloc] init];
    [self performSelector:@selector(getAddressDetails) withObject:nil afterDelay:0.0];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{

    [super viewWillAppear:true];
    
    [self ZoomLocation];
}

-(void)ZoomLocation{
    
    CLLocationCoordinate2D zoomLocation;

    if (appDelegate.currentLocation != nil) {
        //        longitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude];
        //        latitudeLabel.text = [NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude];
        
//        zoomLocation.latitude = appDelegate.currentLocation.coordinate.latitude;
//        zoomLocation.longitude = appDelegate.currentLocation.coordinate.longitude;

               zoomLocation.latitude = 36.840180;
               zoomLocation.longitude= -75.978080;

        
    }else{
        return;
//        zoomLocation.latitude = 23.049844;
//        zoomLocation.longitude= 72.5151166;
    }
    
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(zoomLocation, 0.5*METERS_PER_MILE, 0.5*METERS_PER_MILE);
    [mapViewMain setRegion:viewRegion animated:YES];
}

#pragma mark -

-(CLLocationCoordinate2D) currentLocation{
    CLLocationCoordinate2D location;
    location.latitude =  36.840180;
    location.longitude = -75.978080;
    
    return location;
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
    
    NSLog(@"viewForAnnotation...");
    
    static NSString *identifier = @"MyLocation";
    if ([annotation isKindOfClass:[MyLocation class]]) {
        
        MKAnnotationView *annotationView = (MKAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
        
        if (annotationView == nil){
            annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        }
        
        if (annotation == mapView.userLocation)
            return nil;
        
//        UIButton *advertButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
//        [advertButton addTarget:self action:@selector(getPinDetails:) forControlEvents:UIControlEventTouchUpInside];
//        annotationView.rightCalloutAccessoryView = advertButton;
        
        annotationView.image = [UIImage imageNamed:@"pin_black.png"];
        annotationView.annotation = annotation;
        annotationView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];        
        annotationView.rightCalloutAccessoryView.tag = 101;
        
        annotationView.canShowCallout = YES;
        //	annotationView.animatesDrop = YES;
        return annotationView;
    }
    
    return nil;
}
- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control{
    NSLog(@"calloutAccessoryControlTapped...");
    NSLog(@"title...%@",view.annotation.title);
    NSLog(@"title...%@",view.annotation.subtitle);

    
    MeterVC *objMeterVC = [[MeterVC alloc]initWithNibName:@"MeterVC" bundle:nil];
    objMeterVC.strLat = [[NSString alloc] initWithString:[NSString stringWithFormat:@"%f",[self currentLocation].latitude]];
    objMeterVC.strLong = [[NSString alloc] initWithString:[NSString stringWithFormat:@"%f",[self currentLocation].longitude]];
    objMeterVC.strIsFromParkNow = @"yes";
    [self.navigationController pushViewController:objMeterVC animated:YES];
    
}

-(IBAction)getPinDetails:(UIButton *)sender {
//    NSLog(@"getPinDetails...%d",sender.tag);

}

- (void)plotPositions{
    
    NSLog(@"plotCrimePositions...");
    
    
    for (id<MKAnnotation> annotation in mapViewMain.annotations) {
        [mapViewMain removeAnnotation:annotation];
    }
    
    
    CLLocationCoordinate2D coordinate;
    for (int i=0; i<1; i++) {
        
//        NSString * strDes =[NSString stringWithFormat:@"test desc:%d",i+1];
//        NSString * address = [NSString stringWithFormat:@"test addre:%d",i+1];
        
        coordinate.latitude = 36.840180;
        coordinate.longitude = -75.978080;
//        MyLocation *annotation = [[MyLocation alloc] initWithName:strDes address:address coordinate:coordinate] ;
        MyLocation *annotation = [[MyLocation alloc] initWithName:strFullAddr address:@"" strTag:[NSString stringWithFormat:@"%d",i] coordinate:coordinate] ;
        
        [mapViewMain addAnnotation:annotation];
    }
    
    [self performSelector:@selector(ZoomLocation) withObject:nil afterDelay:2.0];
    
    
    /* if more pin...
     NSDictionary * root = [responseString JSONValue];
     NSArray *data = [root objectForKey:@"data"];
     
     for (NSArray * row in data) {
     
     NSNumber * latitude = [[row objectAtIndex:21]objectAtIndex:1];
     NSNumber * longitude = [[row objectAtIndex:21]objectAtIndex:2];
     NSString * crimeDescription =@"test desc...";
     NSString * address = @"test address...";
     
     CLLocationCoordinate2D coordinate;
     coordinate.latitude = latitude.doubleValue;
     coordinate.longitude = longitude.doubleValue;
     MyLocation *annotation = [[MyLocation alloc] initWithName:crimeDescription address:address coordinate:coordinate] ;
     [mapTest addAnnotation:annotation];
     }
     */
    MKCoordinateRegion region;
    region.center = coordinate;
    region.span.latitudeDelta = 10.0;
    region.span.longitudeDelta = 10.0;
    
    
    MKCoordinateRegion adjustedRegion = [mapViewMain regionThatFits:region];
    [mapViewMain setRegion:adjustedRegion animated:YES];
    [mapViewMain setZoomEnabled:YES];
    
    
    /*
     [theMapView setZoomEnabled:YES];
     theMapView.showsUserLocation = YES;
     MKCoordinateRegion region;
     region.center = currentLocation;
     region.span.latitudeDelta = 0.03;
     region.span.longitudeDelta = 0.03;
     
     [theMapView setMapType:MKMapTypeStandard];
     [theMapView setZoomEnabled:NO];
     //	[theMapView setScrollEnabled:NO];
     [theMapView setRegion:region animated:YES];
     */
    
}



#pragma mark -
-(void)getAddressDetails{
    
    NSLog(@"getAddressDetails");

    
    NSString *urlString = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=false",[self currentLocation].latitude, [self currentLocation].longitude];
    NSError* error;
    NSLog(@"urlString:%@",urlString);
    NSString *locationString = [NSString stringWithContentsOfURL:[NSURL URLWithString:urlString] encoding:NSASCIIStringEncoding error:&error];
    
    NSData *data = [locationString dataUsingEncoding:NSUTF8StringEncoding];
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    
    NSDictionary *dic = [[json objectForKey:@"results"] objectAtIndex:0];
    NSArray* arr = [dic objectForKey:@"address_components"];
    strFullAddr = [dic valueForKey:@"formatted_address"];
    
    NSString *streetNo;
    NSString *postalCode;
    NSString *cityName;
    NSString *countryName;
    NSString *placeId = [dic valueForKey:@"place_id"];

    for (NSDictionary* d in arr)
    {
        NSArray* typesArr = [d objectForKey:@"types"];
        NSString* firstType = [typesArr objectAtIndex:0];
        
        if([firstType isEqualToString:@"street_number"])
            streetNo = [d objectForKey:@"short_name"];
        
        if([firstType isEqualToString:@"postal_code"])
            postalCode = [d objectForKey:@"short_name"];

        
        if([firstType isEqualToString:@"locality"])
            cityName = [d objectForKey:@"long_name"];
        
        if([firstType isEqualToString:@"country"])
            countryName = [d objectForKey:@"long_name"];
        
    }
    
    NSString* locationFinal = [NSString stringWithFormat:@"%@,%@,%@",streetNo,cityName,countryName];
    NSLog(@"locationFinal %@",locationFinal);
    
    [self performSelector:@selector(plotPositions) withObject:nil afterDelay:0.1];

    
    /*
    
    //
    CLGeocoder *ceo = [[CLGeocoder alloc]init];
    CLLocation *loc = [[CLLocation alloc]initWithLatitude:32.00 longitude:21.322]; //insert your coordinates
    
    [ceo reverseGeocodeLocation:loc completionHandler:^(NSArray *placemarks, NSError *error) {
        CLPlacemark *placemark = placemarks[0];
        NSDictionary *addressDictionary = [placemark addressDictionary];
        
        
        NSLog(@"addressDictionary %@",addressDictionary);

    }];
    
    
    [ceo reverseGeocodeLocation:loc
              completionHandler:^(NSArray *placemarks, NSError *error) {
                  CLPlacemark *placemark = [placemarks objectAtIndex:0];
                  if (placemark) {
                      
                      
                      NSLog(@"placemark %@",placemark);
                      //String to hold address
                      NSString *locatedAt = [[placemark.addressDictionary valueForKey:@"FormattedAddressLines"] componentsJoinedByString:@", "];
                      NSLog(@"addressDictionary %@", placemark.addressDictionary);
                      
                      NSLog(@"placemark %@",placemark.region);
                      NSLog(@"placemark %@",placemark.country);  // Give Country Name
                      NSLog(@"placemark %@",placemark.locality); // Extract the city name
                      NSLog(@"location %@",placemark.name);
                      NSLog(@"location %@",placemark.ocean);
                      NSLog(@"location %@",placemark.postalCode);
                      NSLog(@"location %@",placemark.subLocality);
                      
                      NSLog(@"location %@",placemark.location);
                      //Print the location to console
                      NSLog(@"I am currently at %@",locatedAt);
                  }
                  else {
                      NSLog(@"Could not locate");
                  }
              }
     ];
     
     */
}

#pragma mark - 


@end
