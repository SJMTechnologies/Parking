//
//  PaymentVC.h
//  Parking_ios
//
//  Created by Dips here... on 6/30/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "Constant.h"
#import "MBProgressHUD.h"

@interface PaymentVC : UIViewController<UIWebViewDelegate>{


    IBOutlet UIWebView *wvMain;
    
    NSMutableDictionary *dictData;
    NSMutableDictionary *dictProfile;
    NSDictionary *dictLogin;
    AppDelegate *appDelegate;
}
@property(nonatomic,retain)NSMutableDictionary *dictData;
@property(nonatomic,retain)IBOutlet UIWebView *wvMain;
@end
