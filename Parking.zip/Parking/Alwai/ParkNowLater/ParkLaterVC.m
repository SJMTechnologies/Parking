//
//  ParkLaterVC.m
//  Parking_ios
//
//  Created by Dips here... on 6/12/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import "ParkLaterVC.h"

@interface ParkLaterVC ()

@end

@implementation ParkLaterVC

@synthesize txtDate,txtTime;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    self.title = @"Park Later";
    appDelegate = APPDELEGATE;

    dpDob = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-216, self.view.frame.size.width, 216)];
    dpDob.datePickerMode = UIDatePickerModeDate;
    dpDob.maximumDate = [NSDate date];
//    [dpDob addTarget:self action:@selector(action_datePicker:) forControlEvents:UIControlEventValueChanged];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -

-(IBAction)action_datePicker:(UIDatePicker*)sender{
    if(sender.tag == 0){
    }else{
    }
}

#pragma mark -
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldShouldBeginEditing...");
     NSLog(@"%@",textField.placeholder);
    
    return true;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    NSLog(@"textFieldShouldEndEditing...");
    // NSLog(@"%@",textField.placeholder);
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];

    NSLog(@"textField.text b4:,%@",dpDob.date);
    if (textField.tag == 0){
        [formatter setDateFormat:@"dd/MM/yyyy"];
        [txtDate setText:[formatter stringFromDate:dpDob.date]];
    }else if(textField.tag == 1){
        [formatter setDateFormat:@"HH:mm"];
        [txtTime setText:[formatter stringFromDate:dpDob.date]];
    }
    
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSLog(@"textFieldShouldReturn...");
    //  NSLog(@"%@",textField.placeholder);
    
    return true;
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    NSLog(@"textFieldDidEndEditing...");
    // NSLog(@"%@",textField.placeholder);
    
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldDidBeginEditing...");
    NSLog(@"%ld",(long)textField.tag);
    
    txtDate.inputView = nil;
    
    if (textField.tag == 0){
        dpDob.datePickerMode = UIDatePickerModeDate;
        txtDate.inputView = dpDob;
        dpDob.tag = 0;
    }else if(textField.tag == 1){
        dpDob.datePickerMode = UIDatePickerModeTime;
        //        NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"NL"];
        //        [dpDob setLocale:locale];
        [dpDob setLocale:[NSLocale systemLocale]];
        txtTime.inputView = dpDob;
        dpDob.tag = 1;
    }
    
}

#pragma mark -
-(void)getMeters{

}


#pragma mark -


@end
