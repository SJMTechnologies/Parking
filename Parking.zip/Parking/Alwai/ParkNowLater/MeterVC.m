//
//  MeterVC.m
//  Parking_ios
//
//  Created by Dips here... on 6/30/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import "MeterVC.h"
#import "PaymentVC.h"

@interface MeterVC ()

@end

@implementation MeterVC

@synthesize lblPrice, lblMinuteCount;
@synthesize strLat,strLong;
@synthesize strIsFromParkNow;
@synthesize strAddress;


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    appDelegate = APPDELEGATE;
    

    
    self.lblPrice.text = @"$1.75";
    self.lblMinuteCount.text = @"01:00";
    
    if([strIsFromParkNow isEqualToString:@"no"]){
        [self checkMeterAvailable];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -

- (IBAction)action_PlusMinus:(UIButton *)sender {
    int intCount = [[NSString stringWithFormat:@"%@",[[self.lblMinuteCount.text componentsSeparatedByString:@":"] objectAtIndex:0]] intValue];
    NSLog(@"intCount:%d",intCount);

    if(sender.tag == 0){
        intCount = intCount + 1 ;
        self.lblPrice.text =  [NSString stringWithFormat:@"$%.2f",[[NSString stringWithFormat:@"%@",[self.lblPrice.text stringByReplacingOccurrencesOfString:@"$" withString:@""]] floatValue] + 1.75];
        self.lblMinuteCount.text = [NSString stringWithFormat:@"%d:00",intCount];
    }else{
        if (intCount != 1){
            intCount = intCount - 1 ;
            self.lblPrice.text =  [NSString stringWithFormat:@"$%.2f",[[NSString stringWithFormat:@"%@",[self.lblPrice.text stringByReplacingOccurrencesOfString:@"$" withString:@""]] floatValue] - 1.75];
            self.lblMinuteCount.text = [NSString stringWithFormat:@"%d:00",intCount];

        }
    }
    
}
- (IBAction)action_YesNo:(UIButton *)sender {
    
    if(sender.tag == 0){
        PaymentVC *objPaymentVC  = [[PaymentVC alloc] initWithNibName:@"PaymentVC" bundle:nil];
        
        if([strIsFromParkNow isEqualToString:@"yes"]){
            objPaymentVC.dictData = [[NSMutableDictionary alloc] init];
            [objPaymentVC.dictData setValue:@"" forKey:@"area"]; //empty
            [objPaymentVC.dictData setValue:strAddress forKey:@"post"]; // address
            [objPaymentVC.dictData setValue:[NSString stringWithFormat:@"%@",[[self.lblMinuteCount.text componentsSeparatedByString:@":"] objectAtIndex:0]] forKey:@"totaltime"];
            [objPaymentVC.dictData setValue:[NSString stringWithFormat:@"%@",[self.lblPrice.text stringByReplacingOccurrencesOfString:@"$" withString:@""]] forKey:@"amount"];
            [objPaymentVC.dictData setValue:strLat forKey:@"lat"];
            [objPaymentVC.dictData setValue:strLong forKey:@"long"];
            [objPaymentVC.dictData setValue:@"" forKey:@"time"];
            [objPaymentVC.dictData setValue:@"" forKey:@"date"];
        }else{
        
        }

        [self.navigationController pushViewController:objPaymentVC animated:YES];
    }else{
        [self.navigationController popViewControllerAnimated:true];
    }

}

#pragma mark -
-(void)checkMeterAvailable{
    if ([appDelegate check_InternetConnection]){
        [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        
        NSDictionary *dictLogin = [[NSDictionary alloc] initWithDictionary:[appDelegate login_getDetails]];
        NSLog(@"dictLogin:%@",dictLogin);
        

        
        NSString *post = [NSString stringWithFormat:@"%@auth_token=%@&latitude=%@&longit=%@",service_getMeter,[dictLogin valueForKey:@"auth_token"],strLat,strLong];
        NSLog(@"meter URL:%@",post);
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:post]];
        [request setHTTPMethod:@"GET"];
        [request setTimeoutInterval:240];
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                    completionHandler:^
                                          (NSData *data, NSURLResponse *response, NSError *error) {
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                              });
                                              
                                              if (error) {
                                                  NSLog(@"error is: %@", error);
                                              } else {
                                                  NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                  NSLog(@"httpResponse:%@", httpResponse);
                                                  NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                  if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                      NSLog(@"dictRes --> %@", dictRes);
                                                      
                                                      if ([[[[dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              
                                                              
                                                          });
                                                      }else{
                                                          [appDelegate showMessage:@"Please try again" withTitle:@""];
                                                      }
                                                  }else{
                                                      [appDelegate showMessage:@"Please try again" withTitle:@""];
                                                  }
                                              }
                                          }];
        [dataTask resume];
    }else{
        [appDelegate showMessage:Alert_msg_InternetError withTitle:@""];
    }
}

#pragma mark -


@end
