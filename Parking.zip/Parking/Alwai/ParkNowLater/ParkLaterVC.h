//
//  ParkLaterVC.h
//  Parking_ios
//
//  Created by Dips here... on 6/12/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Constant.h"
#import "AppDelegate.h"
#import "MeterVC.h"


@interface ParkLaterVC : UIViewController<MKMapViewDelegate,UITextFieldDelegate>{

    IBOutlet MKMapView *mapViewMain;
    AppDelegate *appDelegate;

    UIDatePicker *dpDob;

    IBOutlet UITextField *txtDate;
    IBOutlet UITextField *txtTime;

}

@property(nonatomic,retain)IBOutlet UITextField *txtDate;
@property(nonatomic,retain)IBOutlet UITextField *txtTime;

@end
