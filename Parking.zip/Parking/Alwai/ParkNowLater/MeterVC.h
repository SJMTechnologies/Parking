//
//  MeterVC.h
//  Parking_ios
//
//  Created by Dips here... on 6/30/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "Constant.h"
#import "MBProgressHUD.h"


@interface MeterVC : UIViewController{

    IBOutlet UILabel *lblPrice;
    IBOutlet UILabel *lblMinuteCount;
    
    AppDelegate *appDelegate;
    
    NSString *strLat,*strLong;
    NSString *strIsFromParkNow, *strAddress;
    
}

@property(nonatomic,retain)IBOutlet UILabel *lblPrice;
@property(nonatomic,retain)IBOutlet UILabel *lblMinuteCount;

@property(nonatomic,retain)NSString *strLat;
@property(nonatomic,retain)NSString *strLong;
@property(nonatomic,retain)NSString *strIsFromParkNow;
@property(nonatomic,retain)NSString *strAddress;


@end
