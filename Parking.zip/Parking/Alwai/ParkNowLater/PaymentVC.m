//
//  PaymentVC.m
//  Parking_ios
//
//  Created by Dips here... on 6/30/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import "PaymentVC.h"

@interface PaymentVC ()

@end

@implementation PaymentVC
@synthesize dictData;
@synthesize wvMain;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    appDelegate = APPDELEGATE;
    dictProfile = [[NSMutableDictionary alloc] init];

    dictLogin = [[NSDictionary alloc] initWithDictionary:[appDelegate login_getDetails]];
    [self getProfile:[dictLogin valueForKey:@"auth_token"]];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -
-(void)getProfile:(NSString *)strAuth_token{
    NSLog(@"getProfile...");
    
    if ([APPDELEGATE check_InternetConnection]){
        [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        NSString *post = [NSString stringWithFormat:@"%@%@",service_profile,strAuth_token];
        NSLog(@"Profile URL :%@",post);
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:post]];
        [request setHTTPMethod:@"GET"];
        [request setTimeoutInterval:120];
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                    completionHandler:^
                                          (NSData *data, NSURLResponse *response, NSError *error) {
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                              });
                                              
                                              if (error) {
                                                  NSLog(@"error is: %@", error);
                                              } else {
                                                  NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                  NSLog(@"dictRes is: %@", dictRes);
                                                  
                                                  if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                      if ([[[ [dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"code"] intValue] == 1){
                                                          
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              dictProfile = [[NSMutableDictionary alloc] initWithDictionary:[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"0"]];
                                                              NSLog(@"Profile Data :%@",dictProfile);
                                                              [self loadWebview];
                                                          });
                                                      }else{
                                                          [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                      }
                                                  }else{
                                                      [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                  }
                                              }
                                          }];
        [dataTask resume];
    }else{
        [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
    }
    
}
#pragma mark -
-(void)loadWebview{
    NSString *address = @"http://54.162.93.65/services/ekashu/index.php?";
    NSString *params1 = [NSString stringWithFormat:@"auth_token=%@&fname=%@&lname=%@&address=%@&city=%@&zone_id=%@&zip=%@&country_id=%@email=%@&mobile=ios",[dictLogin valueForKey:@"auth_token"],[dictLogin valueForKey:@"firstname"],[dictLogin valueForKey:@"lastname"],[dictLogin valueForKey:@"address_1"],[dictLogin valueForKey:@"city"],[dictLogin valueForKey:@"state_id"],[dictLogin valueForKey:@"postcode"],[dictLogin valueForKey:@"country_id"],[dictLogin valueForKey:@"email"]];
    
    NSString *params2 = [NSString stringWithFormat:@"&longitude=%@&latitude=%@&area=%@&post=%@&total_time=%@&amount=%@&selected_date=%@&selected_time=%@",[dictData valueForKey:@"lat"],[dictData valueForKey:@"long"],[dictData valueForKey:@"area"],[dictData valueForKey:@"post"],[dictData valueForKey:@"totaltime"],[dictData valueForKey:@"amount"],[dictData valueForKey:@"date"],[dictData valueForKey:@"time"]];
    
    NSString *urlString = [NSString stringWithFormat:@"%@%@%@",address,params1,params2];
    NSLog(@"URL :%@",urlString);
    [self.wvMain loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[urlString stringByReplacingOccurrencesOfString:@" " withString:@"%20"]]]];

}

- (void)webViewDidStartLoad:(UIWebView *)webView{
    NSLog(@"webViewDidStartLoad...");

}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    NSLog(@"webViewDidFinishLoad...");

}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    NSLog(@"didFailLoadWithError...");

}



#pragma mark -


@end
