//
//  RegistrationVC.m
//  Copyright © 2017 sjm. All rights reserved.
//

#import "RegistrationVC.h"
#import "cell_Register.h"
#import "Cell_Subscribe.h"



@interface RegistrationVC ()

@end

@implementation RegistrationVC

@synthesize arrCountryList,arrStateList;
@synthesize pvMain;


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"REGISTRATION";
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
//    [self.navigationController.navigationBar setTitleTextAttributes:
//     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];

    self.navigationController.navigationBar.hidden = false;


    self.navigationController.navigationBar.backgroundColor = color_lightBlue;
    self.navigationController.navigationBar.barTintColor = color_lightBlue;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];

    pvMain = [[UIPickerView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-216, self.view.frame.size.width, 216)];
    pvMain.delegate = self;
    pvMain.dataSource = self;
    
   
    
    [self setupView];
  
}

-(void)setupView{
    NSLog(@"setupView...");
    arrTextName = [[NSMutableArray alloc] init];
    
    NSMutableArray *arrPersonalDetails = [[NSMutableArray alloc] init];
    [arrPersonalDetails addObject:@"First Name"];
    [arrPersonalDetails addObject:@"Last Name"];
    [arrPersonalDetails addObject:@"Email"];
    [arrPersonalDetails addObject:@"Telephone"];
    [arrPersonalDetails addObject:@"Business Name"];
    
    NSMutableArray *arrAddressDetails = [[NSMutableArray alloc] init];
    [arrAddressDetails addObject:@"Address 1"];
    [arrAddressDetails addObject:@"Address 2"];
    [arrAddressDetails addObject:@"City"];
    [arrAddressDetails addObject:@"Postal Code"];
    [arrAddressDetails addObject:@"Fax"];
    
    NSMutableArray *arrCountry = [[NSMutableArray alloc] init];
    [arrCountry addObject:@"Country"];
    [arrCountry addObject:@"Region/State"];

    NSMutableArray *arrPassword = [[NSMutableArray alloc] init];
    [arrPassword addObject:@"Password"];
    [arrPassword addObject:@"Confirm Password"];
    
    [arrTextName addObject:arrPersonalDetails];
    [arrTextName addObject:arrAddressDetails];
    [arrTextName addObject:arrCountry];
    [arrTextName addObject:arrPassword];
    
    
    //
    
    
    NSMutableDictionary *dictPersoanlDetails = [[NSMutableDictionary alloc] init];
    [dictPersoanlDetails setValue:@"" forKey:@"First Name"];
    [dictPersoanlDetails setValue:@"" forKey:@"Last Name"];
    [dictPersoanlDetails setValue:@"" forKey:@"Email"];
    [dictPersoanlDetails setValue:@"" forKey:@"Telephone"];
    [dictPersoanlDetails setValue:@"" forKey:@"Business Name"];
    
    NSMutableDictionary *dictAddressDetails = [[NSMutableDictionary alloc] init];
    [dictAddressDetails setValue:@"" forKey:@"Address 1"];
    [dictAddressDetails setValue:@"" forKey:@"Address 2"];
    [dictAddressDetails setValue:@"" forKey:@"City"];
    [dictAddressDetails setValue:@"" forKey:@"Postal Code"];
    [dictAddressDetails setValue:@"" forKey:@"Fax"];
    
    NSMutableDictionary *dictCountry = [[NSMutableDictionary alloc] init];
    [dictCountry setValue:@"" forKey:@"Country"];
    [dictCountry setValue:@"" forKey:@"CountryID"];
    [dictCountry setValue:@"" forKey:@"Region/State"];
    [dictCountry setValue:@"" forKey:@"Region/StateID"];
    
    NSMutableDictionary *dictPassword = [[NSMutableDictionary alloc] init];
    [dictPassword setValue:@"" forKey:@"Password"];
    [dictPassword setValue:@"" forKey:@"Confirm Password"];
    [dictPassword setValue:@"false" forKey:@"IsShowPassword"];
    [dictPassword setValue:@"false" forKey:@"IsShowConfirm Password"];
    
    NSMutableDictionary *dictNewsletter = [[NSMutableDictionary alloc] init];
    [dictNewsletter setValue:@"false" forKey:@"isSubscribe"];
    [dictNewsletter setValue:@"false" forKey:@"T&C"];

    arrSetData = [[NSMutableArray alloc] init];
    [arrSetData addObject:dictPersoanlDetails];
    [arrSetData addObject:dictAddressDetails];
    [arrSetData addObject:dictCountry];
    [arrSetData addObject:dictPassword];
    [arrSetData addObject:dictNewsletter];
    

    pvMain.delegate = self;
    pvMain.dataSource = self;
    
    arrCountryList = [[NSMutableArray alloc] init];
    arrStateList = [[NSMutableArray alloc] init];
   [self getCountryList];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark -


- (void)getCountryList{
    
    
    if ([APPDELEGATE check_InternetConnection]){
        [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        NSString *post = [NSString stringWithFormat:@"%@",service_country];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:post]];
        [request setHTTPMethod:@"GET"];
        [request setTimeoutInterval:120];
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                    completionHandler:^
                                          (NSData *data, NSURLResponse *response, NSError *error) {
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                              });
                                              
                                              if (error) {
                                                  NSLog(@"error is: %@", error);
                                              } else {
                                                  NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                  if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                      if ([[[ [dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"code"] intValue] == 1){
                                                          
                                                          
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [arrCountryList removeAllObjects];
                                                              for (int i=0; i<[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] count]-1;i++){
                                                                  [arrCountryList insertObject:[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:[NSString stringWithFormat:@"%d",i]] atIndex:i];
                                                              }
                                                              if ([arrCountryList count] > 0){
                                                                  [[arrSetData objectAtIndex:2] setValue:[[arrCountryList objectAtIndex:0] valueForKey:@"name"] forKey:@"Country"];
                                                                  [[arrSetData objectAtIndex:2] setValue:[[arrCountryList objectAtIndex:0] valueForKey:@"country_id"] forKey:@"CountryID"];
                                                                  [self getStateList:[[arrCountryList objectAtIndex:0] valueForKey:@"country_id"]];
                                                              }

                                                          });
                                                      }else{
//                                                          [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                      }
                                                  }else{
//                                                      [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                  }
                                              }
                                          }];
        [dataTask resume];
    }else{
        [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
    }
}
- (void)getStateList:(NSString *)strCountryID{
    
    
    if ([APPDELEGATE check_InternetConnection]){
        [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
        NSString *post = [NSString stringWithFormat:@"%@%@",service_state,strCountryID];
        
        NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
        [request setURL:[NSURL URLWithString:post]];
        [request setHTTPMethod:@"GET"];
        [request setTimeoutInterval:120];
        
        NSURLSession *session = [NSURLSession sharedSession];
        NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                    completionHandler:^
                                          (NSData *data, NSURLResponse *response, NSError *error) {
                                              
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                              });
                                              
                                              if (error) {
                                                  NSLog(@"error is: %@", error);
                                              } else {
                                                  NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                  if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                      if ([[[ [dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:@"code"] intValue] == 1){
                                                          
                                                          
                                                          dispatch_async(dispatch_get_main_queue(), ^{
                                                              [arrStateList removeAllObjects];
                                                              for (int i=0; i<[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] count]-1;i++){
                                                                  [arrStateList insertObject:[[[dictRes valueForKey:@"result"] valueForKey:@"rows"] valueForKey:[NSString stringWithFormat:@"%d",i]] atIndex:i];
                                                              }
                                                              
                                                              if ([arrStateList count] > 0){
                                                                  [[arrSetData objectAtIndex:2] setValue:[[arrStateList objectAtIndex:0] valueForKey:@"name"] forKey:@"Region/State"];
                                                                  [[arrSetData objectAtIndex:2] setValue:[[arrStateList objectAtIndex:0] valueForKey:@"zone_id"] forKey:@"Region/StateID"];
                                                              }
                                                          });
                                                      }else{
                                                          //                                                          [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                      }
                                                  }else{
                                                      //                                                      [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                  }
                                              }
                                          }];
        [dataTask resume];
    }else{
        [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
    }
}




#pragma mark -


- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 4){
        return 80.0;
    }else{
        return 0.0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section != 4){
        return nil;
    }
    UIView *viewFooter  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tblMain.frame.size.width, 50)];
    [viewFooter setBackgroundColor:[UIColor clearColor]];
    
    UIButton *btnSubmit = [[UIButton alloc] initWithFrame:CGRectMake((tblMain.frame.size.width - 200)/2 , 5, 200, 40)];
    [btnSubmit setTitle:@"Continue" forState:UIControlStateNormal];
    [btnSubmit setBackgroundColor:color_lightBlue];
    [btnSubmit setTintColor:[UIColor whiteColor]];
    [btnSubmit.layer setCornerRadius:5];
    [btnSubmit addTarget:self action:@selector(action_continue) forControlEvents:UIControlEventTouchUpInside];
    [viewFooter addSubview:btnSubmit];
    return viewFooter;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    UIView *viewHeader = [[UIView alloc] initWithFrame:CGRectMake(15, 0, self.view.frame.size.width-30, 50)];
    
    UILabel *lblTittle = [[UILabel alloc] initWithFrame:viewHeader.frame];
    lblTittle.backgroundColor = [UIColor clearColor];
    [lblTittle setTextColor:[UIColor blackColor]];
    [lblTittle setFont:[UIFont systemFontOfSize:22]];
    
    if (section == 0){
        lblTittle.text = @"Your Personal Details";
    }else if (section == 1){
        lblTittle.text = @"Your Address";
    }else if (section == 2){
        lblTittle.text = @"Your Country";
    }else if (section == 3){
        lblTittle.text = @"Your Password";
    }else{
        lblTittle.text = @"Newsletter";
    }
    
    [viewHeader addSubview:lblTittle];
    return viewHeader;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    int intRow = 0;
    
    if (section == 0){
        intRow = 5;
    }else if (section == 1){
        intRow = 5;
    }else if (section == 2){
        intRow = 2;
    }else if (section == 3){
        intRow = 2;
    }else{
        intRow = 1;
    }
    return intRow;
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    float flRowHeight = 00.0;
    
    if(indexPath.section == 4){
        flRowHeight = 130.0;
    }else{
        flRowHeight = 70.0;
    }
    
    return flRowHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if(indexPath.section != 4){
        static NSString *MyIdentifier = @"id_cell_Register";
        
        cell_Register *cell = (cell_Register *)[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        if (cell == nil){
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"cell_Register" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
            cell.txtRegi.placeholder = [[arrTextName objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
            cell.txtRegi.text = [[arrSetData objectAtIndex:indexPath.section] valueForKey:[[arrTextName objectAtIndex:indexPath.section] objectAtIndex:indexPath.row]];
            cell.txtRegi.tag = indexPath.row;
            cell.txtRegi.accessibilityValue = [NSString stringWithFormat:@"%d",(int)indexPath.section];
        
        /*
         cell.txtRegi.inputView = nil;
         [cell.txtRegi reloadInputViews];
         if (([[arrTextName objectAtIndex:indexPath.row] isEqualToString:@"Date of Birth"])){
         cell.txtRegi.inputView = dpDob;
         dpDob.tag = indexPath.row;
         txtDobTemp = cell.txtRegi;
         }
         */
            cell.txtRegi.inputView = nil;
            if (indexPath.section == 2){
                pvMain.tag = indexPath.row;
                cell.txtRegi.inputView = pvMain;
            }
        
        if(indexPath.section == 3){
            if ([[[arrSetData objectAtIndex:indexPath.section] valueForKey:[NSString stringWithFormat:@"IsShow%@",[[arrTextName objectAtIndex:indexPath.section] objectAtIndex:indexPath.row]]] isEqualToString:@"true"]){
                [cell.txtRegi setSecureTextEntry:false];
            }else{
                [cell.txtRegi setSecureTextEntry:true];
            }
            cell.btnHideShowPasswod.hidden = false;
        }else{
            cell.btnHideShowPasswod.hidden = true;
            [cell.txtRegi setSecureTextEntry:false];
        }
        cell.btnHideShowPasswod.tag = indexPath.row;
        [cell.btnHideShowPasswod addTarget:self action:@selector(action_hideShowPassword:) forControlEvents:UIControlEventTouchUpInside];
        return cell;

    }else{
        static NSString *MyIdentifier = @"id_Cell_Subscribe";
        
        Cell_Subscribe *cell = (Cell_Subscribe *)[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
        if (cell == nil){
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Cell_Subscribe" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        
        if([[[arrSetData objectAtIndex:indexPath.section] valueForKey:@"isSubscribe"] isEqualToString:@"false"]){
            [cell.btnSubscribeYes setImage:[UIImage imageNamed:@"radio_u.png"] forState:UIControlStateNormal];
            [cell.btnSubscribeNo setImage:[UIImage imageNamed:@"radio_s.png"] forState:UIControlStateNormal];
        }else{
            [cell.btnSubscribeYes setImage:[UIImage imageNamed:@"radio_s.png"] forState:UIControlStateNormal];
            [cell.btnSubscribeNo setImage:[UIImage imageNamed:@"radio_u.png"] forState:UIControlStateNormal];
        }
        
        if([[[arrSetData objectAtIndex:indexPath.section] valueForKey:@"T&C"] isEqualToString:@"false"]){
            [cell.btnPrivacyPolicy setImage:[UIImage imageNamed:@"uncheck.png"] forState:UIControlStateNormal];
        }else{
            [cell.btnPrivacyPolicy setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        }
        
        [cell.btnSubscribeYes setTag:0];
        [cell.btnSubscribeNo setTag:1];
        [cell.btnPrivacyPolicy setTag:2];
        
        [cell.btnSubscribeYes addTarget:self action:@selector(action_SubscribeUnSubscribe:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnSubscribeNo addTarget:self action:@selector(action_SubscribeUnSubscribe:) forControlEvents:UIControlEventTouchUpInside];
        [cell.btnPrivacyPolicy addTarget:self action:@selector(action_SubscribeUnSubscribe:) forControlEvents:UIControlEventTouchUpInside];
        
        return cell;

    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

#pragma mark-

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    NSLog(@"pickerView:%ld",(long)pickerView.tag);
    
    if(pvMain.tag == 0){
        return arrCountryList.count;
    }else{
        return arrStateList.count;
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if(pvMain.tag == 0){
        return [[arrCountryList objectAtIndex:row] valueForKey:@"name"];
    }else{
        return [[arrStateList objectAtIndex:row] valueForKey:@"name"];
    }

}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if(pickerView.tag == 0){
        NSLog(@"Country Name :%@",[[arrCountryList objectAtIndex:row] valueForKey:@"name"]);
        [[arrSetData objectAtIndex:2] setValue:[[arrCountryList objectAtIndex:row] valueForKey:@"name"] forKey:@"Country"];
        [[arrSetData objectAtIndex:2] setValue:[[arrCountryList objectAtIndex:row] valueForKey:@"country_id"] forKey:@"CountryID"];
    }else{
        NSLog(@"State Name :%@",[[arrStateList objectAtIndex:row] valueForKey:@"name"]);
        [[arrSetData objectAtIndex:2] setValue:[[arrStateList objectAtIndex:row] valueForKey:@"name"] forKey:@"Region/State"];
        [[arrSetData objectAtIndex:2] setValue:[[arrStateList objectAtIndex:row] valueForKey:@"zone_id"] forKey:@"Region/StateID"];
        
//        [tblMain reloadRowsAtIndexPaths:[NSArray arrayWithObjects:[NSIndexPath indexPathForRow:1 inSection:2], nil] withRowAnimation:UITableViewRowAnimationFade];
    }
}

#pragma mark-
-(IBAction)action_SubscribeUnSubscribe:(UIButton *)sender{

    if (sender.tag == 0){
        [[arrSetData objectAtIndex:4] setValue:@"true" forKey:@"isSubscribe"];
    }else if (sender.tag == 1){
        [[arrSetData objectAtIndex:4] setValue:@"false" forKey:@"isSubscribe"];
    }else{
        
        if ([[[arrSetData objectAtIndex:4] valueForKey:@"T&C"] isEqualToString:@"false"]){
            [[arrSetData objectAtIndex:4] setValue:@"true" forKey:@"T&C"];
        }else{
            [[arrSetData objectAtIndex:4] setValue:@"false" forKey:@"T&C"];
        }
    }
    
    [tblMain reloadRowsAtIndexPaths:[NSArray arrayWithObjects:[NSIndexPath indexPathForRow:0 inSection:4], nil] withRowAnimation:UITableViewRowAnimationFade];

}

-(IBAction)action_hideShowPassword:(UIButton *)sender{
    NSLog(@"action_hideShowPassword...");
    
    if (sender.tag == 0){
        if ([[[arrSetData objectAtIndex:3] valueForKey:@"IsShowPassword"] isEqualToString:@"false"]){
            [[arrSetData objectAtIndex:3] setValue:@"true" forKey:@"IsShowPassword"];
        }else{
            [[arrSetData objectAtIndex:3] setValue:@"false" forKey:@"IsShowPassword"];
        }
    }else{
        if ([[[arrSetData objectAtIndex:3] valueForKey:@"IsShowConfirm Password"] isEqualToString:@"false"]){
            [[arrSetData objectAtIndex:3] setValue:@"true" forKey:@"IsShowConfirm Password"];
        }else{
            [[arrSetData objectAtIndex:3] setValue:@"false" forKey:@"IsShowConfirm Password"];
        }
    }

    [tblMain reloadRowsAtIndexPaths:[NSArray arrayWithObjects:[NSIndexPath indexPathForRow:sender.tag inSection:3], nil] withRowAnimation:UITableViewRowAnimationFade];
}

-(void)action_continue{
    NSLog(@"action_continue...");
    
    NSLog(@"arrSetData :%@",arrSetData);
    [self checkAllFieldValidation];
    
}

-(void)checkAllFieldValidation{
    NSLog(@"checkAllFieldValidation...");
    
    // first name, last name, email,  tel , add1 , city ,postal code,pass
    
    if ([[MyValidation checkString:[[arrSetData objectAtIndex:0] valueForKey:@"First Name"]] length] == 0){
        [appDelegate showMessage:regi_FirstName withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:0] valueForKey:@"Last Name"]] length] == 0){
        [appDelegate showMessage:regi_LastName withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:0] valueForKey:@"Email"]] length] == 0){
        [appDelegate showMessage:regi_EmailEnter withTitle:@""];
    }else if (![MyValidation checkEmail:[[arrSetData objectAtIndex:0] valueForKey:@"Email"]]){
        [appDelegate showMessage:regi_EmailValidate withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:0] valueForKey:@"Telephone"]] length] == 0){
        [appDelegate showMessage:regi_TelephoneEnter withTitle:@""];
    }else if (![MyValidation checkNumericOnly:[[arrSetData objectAtIndex:0] valueForKey:@"Telephone"]]){
        [appDelegate showMessage:regi_TelephoneValid withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:1] valueForKey:@"Address 1"]] length] == 0){
        [appDelegate showMessage:regi_Address1 withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:1] valueForKey:@"City"]] length] == 0){
        [appDelegate showMessage:regi_City withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:1] valueForKey:@"Postal Code"]] length] == 0){
        [appDelegate showMessage:regi_PostalCodeEnter withTitle:@""];
    }else if (![MyValidation checkNumericOnly:[[arrSetData objectAtIndex:1] valueForKey:@"Postal Code"]]){
        [appDelegate showMessage:regi_PostalCodeValid withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:3] valueForKey:@"Password"]] length] == 0){
        [appDelegate showMessage:regi_PasswordEnter withTitle:@""];
    }else if (![MyValidation checkPasswordStandard:[[arrSetData objectAtIndex:3] valueForKey:@"Password"]]){
        [appDelegate showMessage:regi_PasswordValidate withTitle:@""];
    }else if ([[MyValidation checkString:[[arrSetData objectAtIndex:3] valueForKey:@"Confirm Password"]] length] == 0){
        [appDelegate showMessage:regi_ConfirmPasswordEnter withTitle:@""];
    }else if (![MyValidation checkPasswordStandard:[[arrSetData objectAtIndex:3] valueForKey:@"Confirm Password"]]){
        [appDelegate showMessage:regi_ConfirmPasswordValidate withTitle:@""];
    }else if(![[[arrSetData objectAtIndex:3] valueForKey:@"Password"] isEqualToString:[[arrSetData objectAtIndex:3] valueForKey:@"Confirm Password"]]){
        [appDelegate showMessage:regi_PassConfiPassNotSame withTitle:@""];
    }else if ([[[arrSetData objectAtIndex:4] valueForKey:@"T&C"] isEqualToString:@"false"]){
        [appDelegate showMessage:regi_PrivacyPolicy withTitle:@""];
    }else{
        [self wsCall_Register];
    }
}


#pragma mark-


-(void)wsCall_Register{
//email=&password=&fname=&lname=&business_name=&address=&address2=&city=&state=&zip=&country=&phone=&fax=&subscribe=

    
        if ([APPDELEGATE check_InternetConnection]){
            [MBProgressHUD showHUDAddedTo:self.view animated:TRUE];
            
            NSString *strPersonalDetails = [NSString stringWithFormat:@"fname=%@&lname=%@&email=%@&phone=%@&business_name=%@",
                                            [[arrSetData objectAtIndex:0] valueForKey:@"First Name"],
                                            [[arrSetData objectAtIndex:0] valueForKey:@"Last Name"],
                                            [[arrSetData objectAtIndex:0] valueForKey:@"Email"],
                                            [[arrSetData objectAtIndex:0] valueForKey:@"Telephone"],
                                            [[arrSetData objectAtIndex:0] valueForKey:@"Business Name"]];
            NSString *strAddress = [NSString stringWithFormat:@"&address=%@&address2=%@&city=%@&zip=%@&fax=%@",
                                    [[arrSetData objectAtIndex:1] valueForKey:@"Address 1"],
                                    [[arrSetData objectAtIndex:1] valueForKey:@"Address 2"],
                                    [[arrSetData objectAtIndex:1] valueForKey:@"City"],
                                    [[arrSetData objectAtIndex:1] valueForKey:@"Postal Code"],
                                    [[arrSetData objectAtIndex:1] valueForKey:@"Fax"]];
            
            NSString *strCountry = [NSString stringWithFormat:@"&country=%@&state=%@",
                                    [[arrSetData objectAtIndex:2] valueForKey:@"CountryID"],
                                    [[arrSetData objectAtIndex:2] valueForKey:@"Region/StateID"]];
            
            NSString *strPasswordNews = [NSString stringWithFormat:@"&password=%@&subscribe=%@",
                                         [[arrSetData objectAtIndex:3] valueForKey:@"Password"],
                                         [[arrSetData objectAtIndex:4] valueForKey:@"isSubscribe"]];

            NSString *post = [NSString stringWithFormat:@"%@%@%@%@%@",service_register,strPersonalDetails,strAddress,strCountry,strPasswordNews];
            
            NSLog(@"post:%@",post);

            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
            [request setURL:[NSURL URLWithString:post]];
            [request setHTTPMethod:@"GET"];
            [request setTimeoutInterval:120];
            
            NSURLSession *session = [NSURLSession sharedSession];
            NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:request
                                                        completionHandler:^
                                              (NSData *data, NSURLResponse *response, NSError *error) {
                                                  
                                                  dispatch_async(dispatch_get_main_queue(), ^{
                                                      [MBProgressHUD hideHUDForView:self.view animated:TRUE];
                                                  });
                                                  
                                                  if (error) {
                                                      NSLog(@"error is: %@", error);
                                                  } else {
                                                      NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *) response;
                                                      NSLog(@"httpResponse:%@", httpResponse);
                                                      NSDictionary * dictRes = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error];
                                                      if ([ [dictRes valueForKey:@"result"] count] > 0){
                                                          NSLog(@"Regi dictRes --> %@", dictRes);
                                                          if ([[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"code"] intValue] == 1){
                                                              
                                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                                  [APPDELEGATE showMessage:[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"message"] withTitle:@""];
                                                                  
                                                              });
                                                              
                                                          }else{
                                                              [APPDELEGATE showMessage:[[ [dictRes valueForKey:@"result"] objectAtIndex:0] valueForKey:@"message"] withTitle:@""];
                                                          }
                                                      }else{
                                                          [APPDELEGATE showMessage:Alert_msg_Tryagain withTitle:@""];
                                                      }
                                                  }
                                              }];
            [dataTask resume];
        }else{
            [APPDELEGATE showMessage:Alert_msg_InternetError withTitle:@""];
        }
        
    
    
}




#pragma mark -
-(void)tblReloadSection{
    [tblMain reloadSections:[NSIndexSet indexSetWithIndex:2] withRowAnimation:UITableViewRowAnimationNone];
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    

    NSLog(@"textFieldShouldBeginEditing...");
    //NSLog(@"%ld",(long)textField.tag);
    

    return true;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    NSLog(@"textFieldShouldEndEditing...");
   // NSLog(@"%ld",(long)textField.tag);
    NSLog(@"%d %ld",[textField.accessibilityValue intValue],(long)textField.tag);

    if([textField.accessibilityValue intValue] == 2){
        if(textField.tag == 0){
            
            if ([arrCountryList count] != 1){
                [self getStateList:[[arrSetData objectAtIndex:2] valueForKey:@"CountryID"]];
            }
        }else{
            
        }
        
        [self performSelector:@selector(tblReloadSection) withObject:nil afterDelay:1.0];
    }else{
        NSString *strPlaceholder= [[arrTextName objectAtIndex:[textField.accessibilityValue intValue]] objectAtIndex:textField.tag];
        [[arrSetData objectAtIndex:[textField.accessibilityValue intValue]] setValue:textField.text forKey:strPlaceholder];
    }
    return YES;
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
        NSLog(@"textFieldShouldReturn...");
       // NSLog(@"%@",textField.placeholder);

        return true;
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    NSLog(@"textFieldDidEndEditing...");
   // NSLog(@"%ld",(long)textField.tag);

}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldDidBeginEditing...");
    NSLog(@"%d %ld",[textField.accessibilityValue intValue],(long)textField.tag);
//  
    if([textField.accessibilityValue intValue] == 2){
        pvMain.tag = textField.tag;
    }
    
}



@end
