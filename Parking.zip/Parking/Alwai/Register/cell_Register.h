//
//  cell_Annousement.h
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cell_Register : UITableViewCell{

    IBOutlet UITextField *txtRegi;
    IBOutlet UIButton *btnHideShowPasswod;

}

@property(nonatomic,retain)IBOutlet UITextField *txtRegi;
@property(nonatomic,retain)IBOutlet UIButton *btnHideShowPasswod;

@end
