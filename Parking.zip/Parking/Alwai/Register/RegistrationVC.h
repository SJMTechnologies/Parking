//
//  RegistrationVC.h
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"
#import "AppDelegate.h"
#import "IQKeyboardManager.h"
#import "MBProgressHUD.h"
#import "MyValidation.h"



@interface RegistrationVC : UIViewController<UITextFieldDelegate, UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate,UIPickerViewDataSource>{

    AppDelegate *appDelegate;
    NSMutableArray *arrTextName;

    IBOutlet UITableView *tblMain;

    UIPickerView *pvMain;
    
    NSMutableArray *arrCountryList, *arrStateList;    
    NSMutableArray *arrSetData;
    
    
}

@property(nonatomic,retain)NSMutableArray *arrCountryList;
@property(nonatomic,retain)NSMutableArray *arrStateList;
@property(nonatomic,retain)UIPickerView *pvMain;

@end
