//
//  cell_Annousement.m
//  Copyright © 2017 sjm. All rights reserved.
//

#import "cell_Register.h"


@implementation cell_Register
@synthesize txtRegi;
@synthesize btnHideShowPasswod;

- (void)awakeFromNib {
    [super awakeFromNib];
//    txtRegi.layer.borderColor=[[UIColor lightGrayColor] CGColor];
//    txtRegi.layer.borderWidth=1.0;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
