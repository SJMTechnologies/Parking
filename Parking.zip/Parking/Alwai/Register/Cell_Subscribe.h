//
//  Cell_Subscribe.h
//  Parking_ios
//
//  Created by Dips here... on 6/13/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Cell_Subscribe : UITableViewCell{


    IBOutlet UIButton *btnSubscribeYes, *btnSubscribeNo;
    IBOutlet UIButton *btnPrivacyPolicy;
    
    
}

@property(nonatomic,retain)IBOutlet UIButton *btnSubscribeYes;
@property(nonatomic,retain)IBOutlet UIButton *btnSubscribeNo;

@property(nonatomic,retain)IBOutlet UIButton *btnPrivacyPolicy;

@end
