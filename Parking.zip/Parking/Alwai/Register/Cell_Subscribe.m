//
//  Cell_Subscribe.m
//  Parking_ios
//
//  Created by Dips here... on 6/13/17.
//  Copyright © 2017 sjm. All rights reserved.
//

#import "Cell_Subscribe.h"

@implementation Cell_Subscribe

@synthesize btnSubscribeYes,btnSubscribeNo;
@synthesize btnPrivacyPolicy;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
