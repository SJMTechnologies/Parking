//
//  ProfileVC.h
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "Constant.h"
#import "MyValidation.h"
#import "IQKeyboardManager.h"



@interface ProfileVC : UIViewController<UITextFieldDelegate, UITableViewDelegate,UITableViewDataSource, UIPickerViewDelegate,UIPickerViewDataSource>{

    AppDelegate *appDelegate;
    NSMutableArray *arrTextName;

    IBOutlet UITableView *tblMain;
    IBOutlet UIButton *btnBack;


    UIPickerView *pvMain;
    
    NSMutableArray *arrCountryList, *arrStateList;    
    NSMutableArray *arrSetData;
    
    NSMutableDictionary *dictProfileResponse;
    NSDictionary *dictLogin;
}

@property(nonatomic,retain)NSMutableArray *arrCountryList;
@property(nonatomic,retain)NSMutableArray *arrStateList;
@property(nonatomic,retain)UIPickerView *pvMain;
@property(nonatomic,retain)IBOutlet UIButton *btnBack;

@property(nonatomic,retain)NSMutableDictionary *dictProfileResponse;
@end
