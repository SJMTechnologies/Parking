//
//  Backgroundsynchronization.h
//  Omaha
//
//  Created by Devang Patel on 23/04/15.
//  Copyright (c) 2015 RoaminAround. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Social/Social.h>
#import "AppDelegate.h"
#import <Accounts/Accounts.h>
#import <AVFoundation/AVFoundation.h>
#import "MBProgressHUD.h"

//#import "Reachability.h"

@interface MyValidation : NSObject<UIAlertViewDelegate,UIDocumentInteractionControllerDelegate>{

}


+(NSString *)checkString:(NSString *)strValue;
//+(BOOL)checkConnectedToInternet;
+(BOOL)checkEmail:(NSString *)strValue;
+(BOOL)checkPhone:(NSString *)strValue;
+(BOOL)checkAlphaNumericOnly:(NSString *)strValue;
+(BOOL)checkNumericOnly:(NSString *)strValue;
+(BOOL)checkDigitOnly:(NSString *)strValue;
+(void)checkShowSimpleAlert:(NSString *)title msg:(NSString *)mymsg;
+(UIColor*)checkHexaToRGB:(NSString*)hex;
+(void)checkDismissKeyboard:(UIView *)myView;
+(void)checkDismissPickerView:(UIView *)myView;
+(BOOL)checkPasswordStandard:(NSString *)strValue;

+(void)checkShareFB:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon;
+(void)checkShareTwitter:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon;
+(void)checkShareLinkedInn:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon;
//+(void)checkShareInstagram:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon;
//+(void)checkShareWhatsUpOnlyIMG:(UIImage *)img myVC:(UIViewController *)myViewCon;
+(void)checkShareWhatsUpOnlyString:(NSString *)strMsg myVC:(UIViewController *)myViewCon;

+(NSArray *)checkPostService:(NSString *)strURL dict:(NSMutableDictionary *)myDict;
+(NSArray *)checkGetService:(NSString *)strURL;

+(MBProgressHUD *) showGlobalProgressHUDWithTitle: (NSString *)title;
+(void) dismissGlobalHUD;



@end
