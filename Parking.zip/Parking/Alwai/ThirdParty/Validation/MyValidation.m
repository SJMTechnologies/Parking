//
//  Backgroundsynchronization.m
//  Omaha
//
//  Created by Devang Patel on 23/04/15.
//  Copyright (c) 2015 RoaminAround. All rights reserved.
//

#import "MyValidation.h"
//#import "Constant.h"
//#import "JSON.h"


@implementation MyValidation



#pragma mark - Validation


//
//+(BOOL)checkConnectedToInternet{
//    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
//    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
//    if (networkStatus == NotReachable)
//        return NO;
//    else
//        return YES;
//}


+(NSString *)checkString:(NSString *)strValue {
    
    if([strValue length] == 0 || [strValue isKindOfClass:[NSNull class]] ||  [strValue isEqualToString:@""]  ||  strValue == nil || [strValue isEqualToString:@"<null>"] || [[strValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] length] < 1){
        return @"";
    }
    return strValue;
}


+(BOOL)checkEmail:(NSString *)strValue{

 return [[NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"[A-Z0-9a-z._%+ ]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"]evaluateWithObject:strValue];
   
}

+(BOOL)checkPhone:(NSString *)strValue{
    
    NSString *phoneRegex = @"[0-9]{10}";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    
    return [phoneTest evaluateWithObject:strValue];
  
}

+(BOOL)checkAlphaNumericOnly:(NSString *)strValue{
    
    NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"];
    s = [s invertedSet];
    NSRange r = [strValue rangeOfCharacterFromSet:s];
    if (r.location == NSNotFound)
        return YES;
     else
        return NO;
    
}

+(BOOL)checkNumericOnly:(NSString *)strValue{
    
    return [[NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"^([+-]?)(?:|0|[1-9]\\d*)(?:\\.\\d*)?$"] evaluateWithObject:strValue];
    
}

+(BOOL)checkDigitOnly:(NSString *)strValue{
    
    return [[NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"^([+-]?)(?:|0|[1-9]\\d*)?$"] evaluateWithObject:strValue];

}

+(void)checkShowSimpleAlert:(NSString *)title msg:(NSString *)mymsg{
    UIAlertView * alert =[[UIAlertView alloc] initWithTitle:title message:mymsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert setDelegate:self];
    [alert show];
}

+(UIColor*)checkHexaToRGB:(NSString*)hex {
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    //for 8 characters
    
    //	range.location = 8;
    //	NSString *String = [cString substringWithRange:range];
    
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
    
}

+(void)checkDismissKeyboard:(UIView *)myView {
    for (UIView *view in [myView subviews]) {
        if ([view isKindOfClass:[UIView class]])  {
            if ([view isKindOfClass:[UITextField class]])  {
                [view resignFirstResponder];
            }
            for (UIView *view2 in [view subviews])  {
                if ([view2 isKindOfClass:[UITextField class]])  {
                    [view2 resignFirstResponder];
                }

                for (UIView *view3 in [view2 subviews])  {
                    if ([view3 isKindOfClass:[UITextField class]])  {
                        [view3 resignFirstResponder];
                    }
                }
            }
        }
    }
    
}

+(void)checkDismissPickerView:(UIView *)myView {
    for (UIView *view in [myView subviews]) {
        if ([view isKindOfClass:[UIView class]])  {
            if([view isKindOfClass:[UIDatePicker class]] || [view isKindOfClass:[UIPickerView class]]){
                [view removeFromSuperview];
                return;
            }
            for (UIView *view2 in [view subviews])  {
                if([view2 isKindOfClass:[UIDatePicker class]] || [view2 isKindOfClass:[UIPickerView class]]){
                    [view2 removeFromSuperview];
                    return;
                }
                
                for (UIView *view3 in [view2 subviews])  {
                    if([view3 isKindOfClass:[UIDatePicker class]] || [view3 isKindOfClass:[UIPickerView class]]){
                        [view3 removeFromSuperview];
                        return;
                    }
                }
            }
        }
    }
    
}

+(BOOL)checkPasswordStandard:(NSString *)strValue{
   // (Minimum 8 characters at least 1 Uppercase Alphabet, 1 Lowercase Alphabet and 1 Number)
    NSString *stricterFilterString = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$";
    NSPredicate *passwordTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", stricterFilterString];
    return [passwordTest evaluateWithObject:strValue];
}

#pragma mark - Social

+(void)checkShareFB:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon{

    SLComposeViewController *controller = [SLComposeViewController
                                           composeViewControllerForServiceType:SLServiceTypeFacebook];
    SLComposeViewControllerCompletionHandler myBlock =
    ^(SLComposeViewControllerResult result){
        if (result == SLComposeViewControllerResultCancelled){
            NSLog(@"Cancelled");
        }else{
            NSLog(@"Done");
        }
        [controller dismissViewControllerAnimated:YES completion:nil];
    };
    controller.completionHandler =myBlock;
    //Adding the Text to the facebook post value from iOS
    [controller setInitialText:strMsg];
    //Adding the URL to the facebook post value from iOS
    //    [controller addURL:[NSURL URLWithString:@"http://www.test.com"]];
    [controller addImage:img];
    [myViewCon presentViewController:controller animated:YES completion:nil];
    
}

+(void)checkShareTwitter:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon{
    
    SLComposeViewController *tweetSheet = [SLComposeViewController
                                           composeViewControllerForServiceType:SLServiceTypeTwitter];
    [tweetSheet setInitialText:strMsg];
    [tweetSheet addURL:[NSURL URLWithString:@""]];
    [tweetSheet addImage:img];
    [myViewCon presentViewController:tweetSheet animated:YES completion:nil];
    
    if ([tweetSheet respondsToSelector:@selector(popoverPresentationController)]) {
        // iOS 8+
        UIPopoverPresentationController *presentationController = [tweetSheet popoverPresentationController];
        presentationController.sourceView = myViewCon.view;
    }
}

+(void)checkShareLinkedInn:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon{
    
    /*
    SLComposeViewController *tweetSheet = [SLComposeViewController
                                           composeViewControllerForServiceType:SLServiceTypeLinkedIn];
    [tweetSheet setInitialText:strMsg];
    [tweetSheet addURL:[NSURL URLWithString:@""]];
    [tweetSheet addImage:img];
    [myViewCon presentViewController:tweetSheet animated:YES completion:nil];
    
    if ([tweetSheet respondsToSelector:@selector(popoverPresentationController)]) {
        // iOS 8+
        UIPopoverPresentationController *presentationController = [tweetSheet popoverPresentationController];
        presentationController.sourceView = myViewCon.view;
    }
    */
}



//+(void)checkShareInstagram:(NSString *)strMsg myImg:(UIImage *)img myVC:(UIViewController *)myViewCon{
//    NSURL *instagramURL = [NSURL URLWithString:@"instagram://app"];
//    
//    if([[UIApplication sharedApplication] canOpenURL:instagramURL]) //check for App is install or not
//    {
//        NSData *imageData = UIImagePNGRepresentation(img); //convert image into .png format.
//        NSFileManager *fileManager = [NSFileManager defaultManager];//create instance of NSFileManager
//        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); //create an array and store result of our search for the documents directory in it
//        NSString *documentsDirectory = [paths objectAtIndex:0]; //create NSString object, that holds our exact path to the documents directory
//        NSString *fullPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"insta.igo"]]; //add our image to the path
//        [fileManager createFileAtPath:fullPath contents:imageData attributes:nil]; //finally save the path (image)
//        NSLog(@"image saved");
//        
//        CGRect rect = CGRectMake(0 ,0 , 0, 0);
//        UIGraphicsBeginImageContextWithOptions(myViewCon.view.bounds.size, myViewCon.view.opaque, 0.0);
//        [myViewCon.view.layer renderInContext:UIGraphicsGetCurrentContext()];
//        UIGraphicsEndImageContext();
//        NSString *fileNameToSave = [NSString stringWithFormat:@"Documents/insta.igo"];
//        NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:fileNameToSave];
//        NSLog(@"jpg path %@",jpgPath);
//        NSString *newJpgPath = [NSString stringWithFormat:@"file://%@",jpgPath];
//        NSLog(@"with File path %@",newJpgPath);
//        NSURL *igImageHookFile = [[NSURL alloc]initFileURLWithPath:newJpgPath];
//        NSLog(@"url Path %@",igImageHookFile);
//        
//        UIDocumentInteractionController *documentController;
//        
//        documentController.UTI = @"com.instagram.exclusivegram";
////        documentController = [self setupControllerWithURL:igImageHookFile usingDelegate:self];
//        documentController = [UIDocumentInteractionController interactionControllerWithURL: igImageHookFile];
//        documentController.delegate = self;
//        documentController=[UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
//        NSString *caption = strMsg; //settext as Default Caption
//        documentController.annotation=[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",caption],@"InstagramCaption", nil];
//        [documentController presentOpenInMenuFromRect:rect inView: myViewCon.view animated:YES];
//    }else{
//        NSLog (@"Instagram not found");
//        [MyValidation checkShowSimpleAlert:@"Instagram app not installed." msg:@"Your device has no Instagram installed."];
//    }
//}


+(void)checkShareWhatsUpOnlyString:(NSString *)strMsg myVC:(UIViewController *)myViewCon{
    NSString * urlWhats = [NSString stringWithFormat:@"whatsapp://send?text=%@",strMsg];
    NSURL * whatsappURL = [NSURL URLWithString:[urlWhats stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    if ([[UIApplication sharedApplication] canOpenURL: whatsappURL]) {
        [[UIApplication sharedApplication] openURL: whatsappURL];
    } else {
        [MyValidation checkShowSimpleAlert:@"WhatsApp not installed." msg:@"Your device has no WhatsApp installed."];
    }
    
}

//+(void)checkShareWhatsUpOnlyIMG:(UIImage *)img myVC:(UIViewController *)myViewCon{
//
//        
//    if ([[UIApplication sharedApplication] canOpenURL: [NSURL URLWithString:@"whatsapp://app"]]){
//        
//        NSString *savePath  = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/whatsAppTmp.wai"];
//        
//        [UIImageJPEGRepresentation(img, 1.0) writeToFile:savePath atomically:YES];
//        
//        UIDocumentInteractionController *objDoct = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:savePath]];
//        [objDoct setUTI:@"net.whatsapp.image"];
//        [objDoct setDelegate:self];
//        [objDoct presentOpenInMenuFromRect:CGRectMake(0, 0, 0, 0) inView:myViewCon.view animated:YES];
//        
//    }else{
//        [MyValidation checkShowSimpleAlert:@"WhatsApp not installed." msg:@"Your device has no WhatsApp installed."];
//    }
//   
//}

/*
- (void) postInstagramImage:(UIImage*) image {
    if ([MGInstagram isAppInstalled]){
        // [MGInstagram postImage:image inView:self.view];
        [MGInstagram postImage:image withCaption:@"#nethizmet #photobooth #eventframe" inView:self.view];
        
    }else{
        
    }
    
}
- (UIAlertView*) notInstalledAlert {
    return [[UIAlertView alloc] initWithTitle:@"Instagram Not Installed!" message:@"Instagram must be installed on the device in order to post images" delegate:nil cancelButtonTitle:@"Okay" otherButtonTitles:nil];
}

*/

+(MBProgressHUD *) showGlobalProgressHUDWithTitle: (NSString *)title
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:window animated:TRUE];//MBProgressHUD
    hud.label.text = title;
    return hud;
}

+(void) dismissGlobalHUD
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [MBProgressHUD hideHUDForView:window animated:TRUE];
}

//class func showGlobalProgressHUDWithTitle(title: String) -> MBProgressHUD{
//    let window:UIWindow = UIApplication.sharedApplication().keyWindow!
//    let hud = MBProgressHUD.showHUDAddedTo(window, animated: true)
//    //hud.labelText = title.length > 0 ? title : "Loading..."
//    hud.labelText = nil
//    return hud
//}
//
//class func dismissGlobalHUD() -> Void{
//    dispatch_async(dispatch_get_main_queue()) { () -> Void in
//        let window:UIWindow = UIApplication.sharedApplication().keyWindow!
//        MBProgressHUD.hideHUDForView(window, animated: true)
//    }
//}
#pragma mark - Service

+(NSArray *)checkPostService:(NSString *)strURL dict:(NSMutableDictionary *)myDict{
    NSError *requestError = nil;

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:myDict
                                                       options:kNilOptions
                                                         error:&requestError];

    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:strURL]];
    NSLog(@"req:%@",request);
    
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setValue:@"json" forHTTPHeaderField:@"Data-Type"];
    [request setValue:[NSString stringWithFormat:@"%lu", (unsigned long)[jsonData length]]  forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody: jsonData];
    
    NSURLResponse *response = nil;
    
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&requestError];
    return [NSJSONSerialization JSONObjectWithData:returnData options:0 error:&requestError];
    
}

+(NSArray *)checkGetService:(NSString *)strURL{
    
    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:strURL]];
    NSLog(@"req:%@",request);
    NSError *requestError = nil;

    NSData *returnData = [ NSURLConnection sendSynchronousRequest:request returningResponse: nil error: nil ];
    return [NSJSONSerialization JSONObjectWithData:returnData options:0 error:&requestError];
}

@end

