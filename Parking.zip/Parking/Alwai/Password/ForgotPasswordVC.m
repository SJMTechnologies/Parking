//
//  ForgotPasswordVC.m
//  Copyright © 2017 sjm. All rights reserved.
//

#import "ForgotPasswordVC.h"
#import "Constant.h"

@interface ForgotPasswordVC ()

@end

@implementation ForgotPasswordVC

@synthesize txtUserName;
@synthesize btnSend, btnBack;


- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"Forgot Password";
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];

    
    
    appDelegate  = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    self.btnSend.layer.cornerRadius = self.btnSend.frame.size.height/2;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)actionBack:(id)sender{
    [self.navigationController popViewControllerAnimated:true];
}
#pragma mark -


-(IBAction)action_Forgot:(id)sender{

    
    
}

#pragma mark -


@end
