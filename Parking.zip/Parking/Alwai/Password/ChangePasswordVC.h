//
//  ChangePasswordVC.h
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MyValidation.h"

@interface ChangePasswordVC : UIViewController<UITextFieldDelegate>{

    IBOutlet UITextField *txtOldPsw, *txtNewPsw, *txtNewPswRepeat;
    
    IBOutlet UIButton *btnDone;
    IBOutlet UIButton *btnBack;

    AppDelegate *appDelegate;
}

@property(nonatomic,retain)IBOutlet UITextField *txtOldPsw;
@property(nonatomic,retain)IBOutlet UITextField *txtNewPsw;
@property(nonatomic,retain)IBOutlet UITextField *txtNewPswRepeat;

@property(nonatomic,retain)IBOutlet UIButton *btnDone;
@property(nonatomic,retain)IBOutlet UIButton *btnBack;

-(IBAction)action_ChangePsw:(id)sender;
@end
