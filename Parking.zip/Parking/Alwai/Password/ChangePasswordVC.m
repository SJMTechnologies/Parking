//
//  ChangePasswordVC.m
//  Copyright © 2017 sjm. All rights reserved.
//

#import "ChangePasswordVC.h"
#import "Constant.h"
#import "MBProgressHUD.h"
#import "SWRevealViewController.h"


@interface ChangePasswordVC ()

@end

@implementation ChangePasswordVC

@synthesize txtOldPsw, txtNewPsw, txtNewPswRepeat;
@synthesize btnDone,btnBack;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    appDelegate =  (AppDelegate *)[[UIApplication sharedApplication] delegate];

    
    self.btnDone.layer.cornerRadius = self.btnDone.frame.size.height/2;
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController ){
        [btnBack addTarget:self.revealViewController action:@selector( revealToggle: ) forControlEvents:UIControlEventTouchUpInside];
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)actionBack:(id)sender{
    [self.navigationController popViewControllerAnimated:true];
}
#pragma mark - 


-(IBAction)action_ChangePsw:(id)sender{
    
    
    if([[MyValidation checkString:self.txtOldPsw.text] length] < 1){
        [appDelegate showMessage:@"" withTitle:@"Please enter the old password"];
    }else if([[MyValidation checkString:self.txtOldPsw.text] length] < 7){
        [appDelegate showMessage:@"" withTitle:@"Please enter the minimum six charaters"];
    }else if([[MyValidation checkString:self.txtNewPsw.text] length] < 1){
        [appDelegate showMessage:@"" withTitle:@"Please enter the new password"];
    }else if([[MyValidation checkString:self.txtNewPsw.text] length] < 7){
        [appDelegate showMessage:@"" withTitle:@"New password should be minimum six charaters long"];
    }else if([[MyValidation checkString:self.txtNewPswRepeat.text] length] < 1){
        [appDelegate showMessage:@"" withTitle:@"Please enter the new repeat password"];
    }else if([[MyValidation checkString:self.txtNewPswRepeat.text] length] < 7){
        [appDelegate showMessage:@"" withTitle:@"Repeat password should be minimum six charaters long"];
    }else if(![self.txtNewPsw.text isEqualToString:self.txtNewPswRepeat.text]){
        [appDelegate showMessage:@"" withTitle:@"New password and new repeat password are not same"];
    }else{
        [self call_ChangePassword];
    }
    
    

}

-(void)call_ChangePassword{
    
   
    

}
#pragma mark -

@end
