//
//  ForgotPasswordVC.h
//  Copyright © 2017 sjm. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ForgotPasswordVC : UIViewController<UITextFieldDelegate>{

    

    AppDelegate *appDelegate;
    
    IBOutlet UITextField  *txtUserName;
    IBOutlet UIButton *btnSend;
    
    IBOutlet UIButton *btnBack;
}
@property(nonatomic,retain)IBOutlet UITextField  *txtUserName;
@property(nonatomic,retain)IBOutlet UIButton *btnSend;

@property(nonatomic,retain)IBOutlet UIButton *btnBack;
@end
